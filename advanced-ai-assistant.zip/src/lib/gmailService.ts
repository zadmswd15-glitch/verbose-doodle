/**
 * Gmail Service for Advanced AI Assistant Platform
 * Handles Gmail OAuth dispatching, MIME formatting, and UTF-8 Base64Url encoding.
 */

/**
 * Encodes a string safely to Base64URL (RFC 4648).
 */
export function base64UrlEncode(str: string): string {
  const b64 = btoa(unescape(encodeURIComponent(str)));
  return b64
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

/**
 * Builds a MIME (RFC 2822) formatted email string with UTF-8 subject header and html content.
 */
export function buildMimeMessage(to: string, from: string, subject: string, htmlContent: string): string {
  // UTF-8 Subject encoding to support Arabic and English safely
  const utf8Subject = `=?utf-8?B?${btoa(unescape(encodeURIComponent(subject)))}?=`;
  
  const emailLines = [
    `To: ${to}`,
    `From: ${from}`,
    `Subject: ${utf8Subject}`,
    'MIME-Version: 1.0',
    'Content-Type: text/html; charset=utf-8',
    'Content-Transfer-Encoding: base64',
    '',
    btoa(unescape(encodeURIComponent(htmlContent)))
  ];

  return base64UrlEncode(emailLines.join('\n'));
}

/**
 * Sends an email using the Google Gmail REST API messages.send endpoint.
 * Requires a valid Google OAuth access token with 'https://www.googleapis.com/auth/gmail.send' scope.
 */
export async function sendEmailViaGmail(
  accessToken: string,
  to: string,
  from: string,
  subject: string,
  htmlContent: string
): Promise<{ success: boolean; id?: string; error?: string }> {
  try {
    const raw = buildMimeMessage(to, from, subject, htmlContent);
    
    const response = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ raw })
    });

    if (!response.ok) {
      const errData = await response.json();
      return {
        success: false,
        error: errData.error?.message || 'Gmail API request rejected'
      };
    }

    const data = await response.json();
    return {
      success: true,
      id: data.id
    };
  } catch (error: any) {
    return {
      success: false,
      error: error.message || 'Unknown network error'
    };
  }
}
