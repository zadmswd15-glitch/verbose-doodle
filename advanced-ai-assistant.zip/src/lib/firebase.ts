import { initializeApp } from 'firebase/app';
import { 
  getFirestore, 
  collection, 
  doc, 
  getDoc, 
  setDoc, 
  getDocs, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  orderBy, 
  limit, 
  where,
  onSnapshot
} from 'firebase/firestore';
import { 
  getAuth, 
  signInAnonymously, 
  onAuthStateChanged,
  User,
  signInWithPopup,
  GoogleAuthProvider
} from 'firebase/auth';
import config from '../../firebase-applet-config.json';

let cachedAccessToken: string | null = null;

export const getCachedAccessToken = () => cachedAccessToken;
export const setCachedAccessToken = (token: string | null) => {
  cachedAccessToken = token;
};

export async function googleSignIn() {
  const provider = new GoogleAuthProvider();
  // Request Chat, Meet, and Gmail Send scopes
  provider.addScope('https://www.googleapis.com/auth/gmail.send');
  provider.addScope('https://www.googleapis.com/auth/chat.spaces');
  provider.addScope('https://www.googleapis.com/auth/chat.spaces.create');
  provider.addScope('https://www.googleapis.com/auth/chat.messages');
  provider.addScope('https://www.googleapis.com/auth/chat.messages.create');
  provider.addScope('https://www.googleapis.com/auth/meetings.space.created');
  provider.addScope('https://www.googleapis.com/auth/meetings.space.readonly');
  provider.addScope('https://www.googleapis.com/auth/meetings.space.settings');

  const result = await signInWithPopup(auth, provider);
  const credential = GoogleAuthProvider.credentialFromResult(result);
  if (credential?.accessToken) {
    cachedAccessToken = credential.accessToken;
  }
  return { user: result.user, token: credential?.accessToken || null };
}

// Initialize Firebase with the auto-generated config
const firebaseApp = initializeApp({
  apiKey: config.apiKey,
  authDomain: config.authDomain,
  projectId: config.projectId,
  storageBucket: config.storageBucket,
  messagingSenderId: config.messagingSenderId,
  appId: config.appId
});

// Access Firestore with the custom databaseId if provided
export const db = getFirestore(firebaseApp, config.firestoreDatabaseId || undefined);
export const auth = getAuth(firebaseApp);

function getOrCreateLocalUid(): string {
  let localUid = localStorage.getItem('app_fallback_uid');
  if (!localUid) {
    localUid = 'local_user_' + Math.random().toString(36).substring(2, 15);
    localStorage.setItem('app_fallback_uid', localUid);
  }
  return localUid;
}

// Initialize anonymous session
export async function initAuth(onUserReady: (user: any) => void, onError: (err: Error) => void) {
  onAuthStateChanged(auth, async (user) => {
    if (user) {
      onUserReady(user);
    } else {
      try {
        const credential = await signInAnonymously(auth);
        if (credential.user) {
          onUserReady(credential.user);
        }
      } catch (error) {
        console.warn("Firebase Auth failed (anonymous auth may be restricted in your GCP project console). Falling back to local virtual user:", error);
        // Fallback to local user ID so the applet operates seamlessly
        const localUid = getOrCreateLocalUid();
        onUserReady({ uid: localUid, isAnonymous: true } as any);
      }
    }
  });
}

// Logging helper for usage statistics
export async function logUsage(userId: string, action: string, details: string) {
  try {
    const logsRef = collection(db, 'users', userId, 'usage_logs');
    await addDoc(logsRef, {
      action,
      details,
      timestamp: Date.now()
    });
  } catch (error) {
    console.error("Failed to log usage:", error);
  }
}

// Helper to load settings
export async function loadSettings(userId: string) {
  try {
    const settingsDoc = doc(db, 'users', userId, 'settings', 'user_config');
    const snap = await getDoc(settingsDoc);
    if (snap.exists()) {
      return snap.data();
    }
  } catch (error) {
    console.error("Failed to load settings:", error);
  }
  return null;
}

// Helper to save settings
export async function saveSettings(userId: string, settings: any) {
  try {
    const settingsDoc = doc(db, 'users', userId, 'settings', 'user_config');
    await setDoc(settingsDoc, settings, { merge: true });
  } catch (error) {
    console.error("Failed to save settings:", error);
  }
}
