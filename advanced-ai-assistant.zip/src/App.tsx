import React, { useState, useEffect } from 'react';
import { 
  db, 
  auth, 
  initAuth, 
  logUsage, 
  loadSettings, 
  saveSettings 
} from './lib/firebase';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  setDoc, 
  doc, 
  deleteDoc, 
  query, 
  orderBy, 
  getDocs 
} from 'firebase/firestore';
import { User } from 'firebase/auth';
import { ChatSession, Message, UserSettings, LearnedKnowledge, UsageLog, Attachment } from './types';
import { LanguageProvider, useTranslation } from './components/LanguageContext';
import { Sidebar } from './components/Sidebar';
import { ChatArea } from './components/ChatArea';
import { SettingsModal } from './components/SettingsModal';
import { UsageHistory } from './components/UsageHistory';
import { KnowledgeBase } from './components/KnowledgeBase';
import { ConnectionsModal } from './components/ConnectionsModal';
import { ProgrammerMode } from './components/ProgrammerMode';
import { ExportModal } from './components/ExportModal';

function AppContent() {
  const { t, language } = useTranslation();
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authError, setAuthError] = useState<Error | null>(null);

  // States for sessions, active session, messages
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  // Advanced configurations states
  const [settings, setSettings] = useState<UserSettings>({
    theme: 'dark',
    language: 'ar',
    temperature: 0.7,
    systemInstruction: '',
    memoryEnabled: true,
    groqKey: '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',
    geminiKey: 'AQ.Ab8RN6LUUDtzdn0itAnpG-_t3j88n5eTAQhoj6ic5o0vdDmDBA',
    openaiKey: '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',
    nanabananaKey: 'AQ.Ab8RN6LUUDtzdn0itAnpG-_t3j88n5eTAQhoj6ic5o0vdDmDBA',
    telegramToken: '8636534844:AAGyv7Zw3B31Pw5WUAwpRXPiSoVa1PeC4EI'
  });

  const [knowledge, setKnowledge] = useState<LearnedKnowledge[]>([]);
  const [usageLogs, setUsageLogs] = useState<UsageLog[]>([]);

  // Modal open states
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isUsageOpen, setIsUsageOpen] = useState(false);
  const [isMemoryOpen, setIsMemoryOpen] = useState(false);
  const [isConnectionsOpen, setIsConnectionsOpen] = useState(false);
  const [isPlaygroundActive, setIsPlaygroundActive] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);

  // 1. Initialize anonymous Firebase Auth
  useEffect(() => {
    initAuth(
      (user) => {
        setCurrentUser(user);
        // Log telemetry
        logUsage(user.uid, 'User Authenticated', `Secure anonymous session initialized for user ${user.uid}`);
      },
      (err) => {
        setAuthError(err);
      }
    );
  }, []);

  // 2. Real-time sync of Chat Sessions from Firestore
  useEffect(() => {
    if (!currentUser) return;

    const sessionsRef = collection(db, 'users', currentUser.uid, 'sessions');
    const q = query(sessionsRef, orderBy('updatedAt', 'desc'));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const loadedSessions: ChatSession[] = [];
      snapshot.forEach((docSnap) => {
        loadedSessions.push({ id: docSnap.id, ...docSnap.data() } as ChatSession);
      });
      setSessions(loadedSessions);

      // Default select the latest session if none is active
      if (loadedSessions.length > 0 && !activeSessionId) {
        setActiveSessionId(loadedSessions[0].id);
      }
    }, (err) => {
      console.error("Firestore sync error:", err);
    });

    return () => unsubscribe();
  }, [currentUser]);

  // 3. Real-time sync of Messages for active session
  useEffect(() => {
    if (!currentUser || !activeSessionId) {
      setMessages([]);
      return;
    }

    const msgsRef = collection(db, 'users', currentUser.uid, 'sessions', activeSessionId, 'messages');
    const q = query(msgsRef, orderBy('timestamp', 'asc'));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const loadedMsgs: Message[] = [];
      snapshot.forEach((docSnap) => {
        loadedMsgs.push({ id: docSnap.id, ...docSnap.data() } as Message);
      });
      setMessages(loadedMsgs);
    });

    return () => unsubscribe();
  }, [currentUser, activeSessionId]);

  // 4. Real-time sync of user settings & long term memory
  useEffect(() => {
    if (!currentUser) return;

    // Load initial settings
    loadSettings(currentUser.uid).then((stored) => {
      const defaultGroqKey = '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';
      const defaultGeminiKey = 'AQ.Ab8RN6LUUDtzdn0itAnpG-_t3j88n5eTAQhoj6ic5o0vdDmDBA';
      const defaultOpenaiKey = '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';
      
      const mergedSettings = {
        theme: 'dark',
        language: 'ar',
        temperature: 0.7,
        systemInstruction: '',
        memoryEnabled: true,
        ...stored,
        groqKey: (stored as any)?.groqKey || defaultGroqKey,
        geminiKey: (stored as any)?.geminiKey || defaultGeminiKey,
        openaiKey: (stored as any)?.openaiKey || defaultOpenaiKey,
        nanabananaKey: (stored as any)?.nanabananaKey || defaultGeminiKey,
        telegramToken: (stored as any)?.telegramToken || '8636534844:AAGyv7Zw3B31Pw5WUAwpRXPiSoVa1PeC4EI',
        openaiModel: (stored as any)?.openaiModel || 'gpt-4o-mini',
        groqModel: (stored as any)?.groqModel || 'llama-3.3-70b-versatile',
        geminiModel: (stored as any)?.geminiModel || 'gemini-3.5-flash'
      };

      setSettings(mergedSettings as UserSettings);

      // Auto-save to Firestore if we loaded empty config or keys weren't initialized
      if (!stored || !(stored as any).groqKey) {
        saveSettings(currentUser.uid, mergedSettings);
      }
    });

    // Sync KnowledgeBase
    const kbRef = collection(db, 'users', currentUser.uid, 'learned_knowledge');
    const kbQuery = query(kbRef, orderBy('createdAt', 'desc'));
    const unsubKb = onSnapshot(kbQuery, (snap) => {
      const items: LearnedKnowledge[] = [];
      snap.forEach((docSnap) => {
        items.push({ id: docSnap.id, ...docSnap.data() } as LearnedKnowledge);
      });
      setKnowledge(items);
    });

    // Sync UsageLogs
    const logsRef = collection(db, 'users', currentUser.uid, 'usage_logs');
    const logsQuery = query(logsRef, orderBy('timestamp', 'desc'));
    const unsubLogs = onSnapshot(logsQuery, (snap) => {
      const items: UsageLog[] = [];
      snap.forEach((docSnap) => {
        items.push({ id: docSnap.id, ...docSnap.data() } as UsageLog);
      });
      setUsageLogs(items);
    });

    return () => {
      unsubKb();
      unsubLogs();
    };
  }, [currentUser]);

  // Create new session helper
  const handleNewChat = async () => {
    if (!currentUser) return;

    try {
      const sessionsRef = collection(db, 'users', currentUser.uid, 'sessions');
      const newDoc = await addDoc(sessionsRef, {
        title: language === 'ar' ? 'محادثة جديدة' : 'New Chat',
        createdAt: Date.now(),
        updatedAt: Date.now(),
        userId: currentUser.uid
      });
      setActiveSessionId(newDoc.id);
      logUsage(currentUser.uid, 'Session Created', `Created a new chat session with ID: ${newDoc.id}`);
    } catch (e) {
      console.error("Failed to create chat session:", e);
    }
  };

  // Delete session helper
  const handleDeleteSession = async (id: string) => {
    if (!currentUser) return;

    try {
      const docRef = doc(db, 'users', currentUser.uid, 'sessions', id);
      await deleteDoc(docRef);
      logUsage(currentUser.uid, 'Session Deleted', `Deleted chat session: ${id}`);
      
      if (activeSessionId === id) {
        setActiveSessionId(null);
      }
    } catch (e) {
      console.error("Failed to delete session:", e);
    }
  };

  // Handle system settings change
  const handleSaveSettings = async (newSettings: UserSettings) => {
    if (!currentUser) return;
    setSettings(newSettings);
    await saveSettings(currentUser.uid, newSettings);
    logUsage(currentUser.uid, 'Settings Updated', `System parameters adjusted (Temp: ${newSettings.temperature})`);
  };

  // Clear entire user telemetry & database
  const handleClearAll = async () => {
    if (!currentUser) return;

    try {
      // 1. Delete all sessions
      const sessionsSnap = await getDocs(collection(db, 'users', currentUser.uid, 'sessions'));
      for (const d of sessionsSnap.docs) {
        await deleteDoc(doc(db, 'users', currentUser.uid, 'sessions', d.id));
      }

      // 2. Delete all knowledge
      const kbSnap = await getDocs(collection(db, 'users', currentUser.uid, 'learned_knowledge'));
      for (const d of kbSnap.docs) {
        await deleteDoc(doc(db, 'users', currentUser.uid, 'learned_knowledge', d.id));
      }

      logUsage(currentUser.uid, 'Storage Cleared', 'User completely purged all local database sessions and history.');
      setActiveSessionId(null);
    } catch (e) {
      console.error(e);
    }
  };

  // Manual Knowledge/Fact entry
  const handleAddFact = async (fact: string, category: string) => {
    if (!currentUser) return;

    try {
      const kbRef = collection(db, 'users', currentUser.uid, 'learned_knowledge');
      await addDoc(kbRef, {
        fact,
        category,
        createdAt: Date.now(),
        autoDetected: false
      });
      logUsage(currentUser.uid, 'Fact Added', `Manually registered long-term fact: "${fact}"`);
    } catch (e) {
      console.error(e);
    }
  };

  // Delete knowledge/fact
  const handleDeleteFact = async (id: string) => {
    if (!currentUser) return;

    try {
      const docRef = doc(db, 'users', currentUser.uid, 'learned_knowledge', id);
      await deleteDoc(docRef);
      logUsage(currentUser.uid, 'Fact Deleted', `Deleted learned fact: ${id}`);
    } catch (e) {
      console.error(e);
    }
  };

  // Sending message logic integrating the Express Backend API
  const handleSendMessage = async (text: string, attachments: Attachment[]) => {
    if (!currentUser) return;

    let targetSessionId = activeSessionId;

    // Create session if none active
    if (!targetSessionId) {
      try {
        const sessionsRef = collection(db, 'users', currentUser.uid, 'sessions');
        const newDoc = await addDoc(sessionsRef, {
          title: text.substring(0, 30) || 'Image Analysis',
          createdAt: Date.now(),
          updatedAt: Date.now(),
          userId: currentUser.uid
        });
        targetSessionId = newDoc.id;
        setActiveSessionId(targetSessionId);
      } catch (e) {
        console.error("Failed to create default session:", e);
        return;
      }
    }

    // Prepare User Message record
    const userMsgData: Omit<Message, 'id'> = {
      role: 'user',
      content: text,
      timestamp: Date.now()
    };
    if (attachments && attachments.length > 0) {
      userMsgData.attachments = attachments;
    }

    try {
      setIsGenerating(true);

      // Store user message in Firestore
      const msgsRef = collection(db, 'users', currentUser.uid, 'sessions', targetSessionId, 'messages');
      await addDoc(msgsRef, userMsgData);

      // Update session's title & updatedAt in Firestore
      const sessionDocRef = doc(db, 'users', currentUser.uid, 'sessions', targetSessionId);
      await setDoc(sessionDocRef, {
        title: text.substring(0, 30) || 'Multimodal Request',
        updatedAt: Date.now()
      }, { merge: true });

      // Log usage telemetry
      logUsage(currentUser.uid, 'Message Sent', `Sent prompt: "${text.substring(0, 40)}..." with ${attachments.length} attachments.`);

      // Gather conversation history (exclude current message)
      const formattedHistory = messages.map(m => ({
        role: m.role,
        content: m.content
      }));

      // Call Full-Stack Express API
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: text,
          history: formattedHistory,
          systemInstruction: settings.systemInstruction,
          temperature: settings.temperature,
          attachments: attachments,
          learnedKnowledge: knowledge, // Pass long term facts for contextual grounding
          activeProvider: settings.activeProvider || 'gemini',
          openaiKey: settings.openaiKey || '',
          groqKey: settings.groqKey || '',
          geminiKey: settings.geminiKey || '',
          nanabananaKey: settings.nanabananaKey || '',
          openaiModel: settings.openaiModel || 'gpt-4o-mini',
          groqModel: settings.groqModel || 'llama-3.3-70b-versatile',
          geminiModel: settings.geminiModel || 'gemini-3.5-flash'
        })
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || 'Server error');
      }

      const replyData = await res.json();

      // Store Model Response
      const modelMsgData: Omit<Message, 'id'> = {
        role: 'model',
        content: replyData.text,
        timestamp: Date.now(),
        ...(replyData.searchSources && { searchSources: replyData.searchSources })
      };
      await addDoc(msgsRef, modelMsgData);

      // 5. Autonomic memory analysis (if enabled)
      if (settings.memoryEnabled && text.trim().length > 10) {
        try {
          const analysisRes = await fetch('/api/analyze-memory', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              message: text,
              existingKnowledge: knowledge
            })
          });

          if (analysisRes.ok) {
            const data = await analysisRes.json();
            if (data.facts && data.facts.length > 0) {
              const kbRef = collection(db, 'users', currentUser.uid, 'learned_knowledge');
              for (const item of data.facts) {
                await addDoc(kbRef, {
                  fact: item.fact,
                  category: item.category || 'preference',
                  createdAt: Date.now(),
                  autoDetected: true
                });
                logUsage(currentUser.uid, 'Auto Fact Saved', `Automatically learned user trait: "${item.fact}"`);
              }
            }
          }
        } catch (memErr) {
          console.warn("Autonomic memory tracking error:", memErr);
        }
      }

    } catch (err: any) {
      console.error(err);
      // Fallback: display elegant system error block
      const errMsgsRef = collection(db, 'users', currentUser.uid, 'sessions', targetSessionId, 'messages');
      await addDoc(errMsgsRef, {
        role: 'model',
        content: `⚠️ **System Error during generation:**\n\n${err.message || 'An unexpected connectivity error occurred. Please verify your GEMINI_API_KEY inside Settings > Secrets.'}`,
        timestamp: Date.now()
      });
    } finally {
      setIsGenerating(false);
    }
  };

  // Metrics helper for usage logs
  const getMetrics = () => {
    let filesCount = 0;
    messages.forEach(m => {
      if (m.attachments) filesCount += m.attachments.length;
    });

    return {
      totalQueries: usageLogs.filter(l => l.action === 'Message Sent').length,
      filesAnalyzed: usageLogs.filter(l => l.action === 'Auto Fact Saved').length + filesCount,
      learnedFacts: knowledge.length
    };
  };

  if (authError) {
    return (
      <div className="h-screen w-screen bg-slate-950 flex flex-col items-center justify-center text-slate-100 font-sans p-6 text-center">
        <div className="p-6 bg-slate-900 border border-slate-800 rounded-3xl max-w-md shadow-xl space-y-4">
          <h2 className="text-lg font-bold text-rose-500">Authentication Failure</h2>
          <p className="text-xs text-slate-400 leading-relaxed">
            Firebase project authentication is offline. Please check your credentials config or local database permissions.
          </p>
          <pre className="p-3 bg-black rounded text-[10px] text-left overflow-x-auto text-rose-300">
            {authError.message}
          </pre>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return (
      <div className="h-screen w-screen bg-slate-950 flex flex-col items-center justify-center text-slate-100 font-sans">
        <div className="flex flex-col items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-indigo-600 flex items-center justify-center animate-spin" style={{ animationDuration: '3s' }}>
            <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
          </div>
          <p className="text-xs text-slate-400 font-mono tracking-widest mt-2">
            PROVISIONING SECURE WORKSPACE...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen w-screen bg-slate-950 text-slate-100 flex overflow-hidden font-sans">
      
      {/* Sidebar navigation */}
      <Sidebar
        userId={currentUser.uid}
        sessions={sessions}
        activeSessionId={activeSessionId}
        setActiveSessionId={setActiveSessionId}
        onNewChat={handleNewChat}
        onDeleteSession={handleDeleteSession}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenUsageLogs={() => setIsUsageOpen(true)}
        onOpenMemory={() => setIsMemoryOpen(true)}
        onOpenConnections={() => setIsConnectionsOpen(true)}
        onOpenExport={() => setIsExportOpen(true)}
        isPlaygroundActive={isPlaygroundActive}
        setIsPlaygroundActive={setIsPlaygroundActive}
      />

      {/* Main workspace */}
      {isPlaygroundActive ? (
        <ProgrammerMode settings={settings} />
      ) : (
        <ChatArea
          messages={messages}
          isGenerating={isGenerating}
          onSendMessage={handleSendMessage}
          activeSessionId={activeSessionId}
          onNewChat={handleNewChat}
          activeProvider={settings.activeProvider || 'gemini'}
          settings={settings}
        />
      )}

      {/* Advanced Connections & Integrations panel */}
      <ConnectionsModal
        isOpen={isConnectionsOpen}
        onClose={() => setIsConnectionsOpen(false)}
        settings={settings}
        onSaveSettings={handleSaveSettings}
      />

      {/* Advanced Configurations panel */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSaveSettings={handleSaveSettings}
        onClearAll={handleClearAll}
      />

      {/* Telemetry analytics history panel */}
      <UsageHistory
        isOpen={isUsageOpen}
        onClose={() => setIsUsageOpen(false)}
        logs={usageLogs}
        metrics={getMetrics()}
        onRefresh={() => logUsage(currentUser.uid, 'Manual Refresh', 'Telemetry usage console manually refreshed.')}
      />

      {/* Long-term memory database manager */}
      <KnowledgeBase
        isOpen={isMemoryOpen}
        onClose={() => setIsMemoryOpen(false)}
        knowledge={knowledge}
        onAddFact={handleAddFact}
        onDeleteFact={handleDeleteFact}
      />

      {/* Modern Export and Telegram Sync Teleport Hub */}
      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        userId={currentUser.uid}
        sessions={sessions}
        knowledge={knowledge}
        usageLogs={usageLogs}
        settings={settings}
      />

    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
}
