import React, { useState } from 'react';
import { X, BarChart2, ShieldAlert, FileText, Database, Send, Calendar, RefreshCcw } from 'lucide-react';
import { useTranslation } from './LanguageContext';
import { UsageLog } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface UsageHistoryProps {
  isOpen: boolean;
  onClose: () => void;
  logs: UsageLog[];
  metrics: {
    totalQueries: number;
    filesAnalyzed: number;
    learnedFacts: number;
  };
  onRefresh: () => void;
}

export const UsageHistory: React.FC<UsageHistoryProps> = ({
  isOpen,
  onClose,
  logs,
  metrics,
  onRefresh
}) => {
  const { t, isRtl } = useTranslation();
  const [filter, setFilter] = useState<string>('');

  const filteredLogs = logs.filter(log => 
    log.action.toLowerCase().includes(filter.toLowerCase()) || 
    log.details.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl shadow-indigo-950/20 overflow-hidden text-slate-100 flex flex-col max-h-[85vh]"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-900/50">
              <div className="flex items-center gap-2">
                <BarChart2 className="w-5 h-5 text-emerald-500 animate-pulse" />
                <h2 className="text-base font-bold tracking-tight">{t.usageTitle}</h2>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={onRefresh}
                  className="text-slate-400 hover:text-white transition-colors p-1.5 rounded-lg hover:bg-slate-800 cursor-pointer"
                  title="Refresh Logs"
                >
                  <RefreshCcw className="w-4 h-4" />
                </button>
                <button
                  onClick={onClose}
                  className="text-slate-400 hover:text-white transition-colors p-1 rounded-lg hover:bg-slate-800 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Content body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Analytics Dashboard Grid */}
              <div className="grid grid-cols-3 gap-4">
                {/* Metric 1 */}
                <div className="bg-slate-950/40 border border-slate-800/85 rounded-2xl p-4 flex flex-col justify-between">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest">
                      {t.totalQueries}
                    </span>
                    <Send className="w-4 h-4 text-slate-600" />
                  </div>
                  <h3 className="text-3xl font-bold font-mono tracking-tight mt-4 text-slate-100">
                    {metrics.totalQueries}
                  </h3>
                </div>

                {/* Metric 2 */}
                <div className="bg-slate-950/40 border border-slate-800/85 rounded-2xl p-4 flex flex-col justify-between">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest">
                      {t.filesAnalyzed}
                    </span>
                    <FileText className="w-4 h-4 text-slate-600" />
                  </div>
                  <h3 className="text-3xl font-bold font-mono tracking-tight mt-4 text-slate-100">
                    {metrics.filesAnalyzed}
                  </h3>
                </div>

                {/* Metric 3 */}
                <div className="bg-slate-950/40 border border-slate-800/85 rounded-2xl p-4 flex flex-col justify-between">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest">
                      {t.learnedFacts}
                    </span>
                    <Database className="w-4 h-4 text-slate-600" />
                  </div>
                  <h3 className="text-3xl font-bold font-mono tracking-tight mt-4 text-slate-100">
                    {metrics.learnedFacts}
                  </h3>
                </div>
              </div>

              {/* Logs Search & Filter */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                    {t.logsTitle}
                  </h4>
                  <input
                    type="text"
                    value={filter}
                    onChange={(e) => setFilter(e.target.value)}
                    placeholder={isRtl ? 'تصفية السجل...' : 'Search logs...'}
                    className="text-xs bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500 font-sans"
                  />
                </div>

                {/* Table list of operations */}
                <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-950/20 max-h-[250px] overflow-y-auto font-sans">
                  {filteredLogs.length === 0 ? (
                    <div className="p-8 text-center text-xs text-slate-500 italic">
                      {isRtl ? 'لا توجد سجلات تفي بشروط البحث.' : 'No matching logs found.'}
                    </div>
                  ) : (
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-slate-950 border-b border-slate-800 text-slate-400 select-none">
                          <th className="p-3 text-right">{t.logAction}</th>
                          <th className="p-3 text-right">{t.logDetails}</th>
                          <th className="p-3 text-right">{t.logTime}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredLogs.map((log) => (
                          <tr key={log.id} className="border-b border-slate-800/60 hover:bg-slate-800/20">
                            <td className="p-3 font-semibold text-indigo-400 text-right">
                              {log.action}
                            </td>
                            <td className="p-3 text-slate-300 max-w-[240px] truncate text-right">
                              {log.details}
                            </td>
                            <td className="p-3 text-slate-500 font-mono text-[10px] text-right">
                              {new Date(log.timestamp).toLocaleTimeString()}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between p-5 border-t border-slate-800 bg-slate-950/40 select-none">
              <span className="text-[10px] text-slate-500 font-mono flex items-center gap-1">
                <ShieldAlert className="w-3.5 h-3.5 text-indigo-500" />
                {isRtl ? 'مؤمن بتشفير تام للطرفين' : 'End-to-End Cryptographic Protection'}
              </span>
              <button
                onClick={onClose}
                className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors cursor-pointer"
              >
                {t.close}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
