import React, { createContext, useContext, useState, useEffect } from 'react';

export type Language = 'ar' | 'en';

const translations = {
  ar: {
    appName: "المساعد الذكي المتقدم",
    appSubtitle: "نظام ذكاء اصطناعي تفاعلي مع ذاكرة وقدرات متقدمة",
    newChat: "محادثة جديدة",
    conversations: "المحادثات السابقة",
    settings: "إعدادات النظام",
    usageLogs: "سجل الاستخدام والتحليلات",
    learnedMemory: "الذاكرة طويلة المدى",
    memoryDesc: "معلومات وتفضيلات تعلمها النظام عنك تلقائياً أثناء المحادثة لتخصيص الإجابات وتوفير سياق مستدام:",
    addCustomFact: "إضافة حقيقة يدوياً",
    factPlaceholder: "مثال: أنا مبرمج ويب وأفضل الواجهات الداكنة...",
    addBtn: "إضافة للذاكرة",
    noMemory: "لم يتم حفظ أي معلومات في الذاكرة بعد. ابدأ بالتحدث وسيتعلم النظام تلقائياً!",
    theme: "المظهر والمرئيات",
    dark: "الوضع الداكن (سليت)",
    light: "الوضع المضيء (نقي)",
    language: "لغة الواجهة",
    systemPrompt: "توجيهات النظام المخصصة (شخصية المساعد)",
    systemPromptPlaceholder: "مثال: أجب دائماً باختصار وبأسلوب تقني متميز...",
    tempLabel: "درجة الابتكار والحرية (Temperature)",
    clearHistory: "مسح السجل بالكامل",
    clearHistoryConfirm: "هل أنت متأكد من مسح جميع المحادثات والذاكرة؟ لا يمكن التراجع!",
    typing: "جاري تحليل الاستفسار وإنتاج الإجابة...",
    chatPlaceholder: "اسأل عن أي شيء، اطلب كتابة أكواد، أو ارفع صور وملفات لتحليلها...",
    noChats: "لا توجد محادثات سابقة. ابدأ محادثة جديدة الآن!",
    emptyChatTitle: "أهلاً بك في منصة الذكاء الاصطناعي الاحترافية",
    emptyChatSubtitle: "بوابة ذكية متكاملة تجمع بين معالجة اللغات الطبيعية، ذاكرة التعلم المستمر، وفهم الوسائط المتعددة.",
    quickPrompts: [
      "اشرح لي مفهوم الحوسبة السحابية باللغة العربية بأسلوب مبسط",
      "Write a TypeScript function to debounce an API query.",
      "اقترح عليّ أفكاراً لمشروع تخرج متميز في الذكاء الاصطناعي",
      "Review a conceptual design of an offline-first mobile architecture."
    ],
    usageTitle: "إحصائيات استخدام النظام",
    totalQueries: "إجمالي الاستفسارات",
    filesAnalyzed: "الوسائط والملفات المحللة",
    learnedFacts: "الحقائق المستخلصة",
    logsTitle: "العمليات والتحليلات المسجلة (Telemetry)",
    logAction: "العملية",
    logDetails: "التفاصيل",
    logTime: "الوقت",
    codeAssistantTitle: "مساعد البرمجة وكتابة الأكواد",
    codeAssistantDesc: "يقوم النظام تلقائياً بالتعرف على الأكواد وعرضها بصيغة منسقة مع إمكانية النسخ والمساعدة الذكية.",
    dragDropText: "اسحب وأسقط الملفات هنا أو انقر للاختيار",
    selectedFiles: "ملفات محددة:",
    imagePreview: "معاينة الصورة",
    unsupportedFile: "ملف غير مدعوم أو حجم زائد",
    saveSettings: "حفظ الإعدادات",
    close: "إغلاق",
    memoryCategory: "التصنيف",
    manual: "يدوي",
    auto: "تلقائي",
    delete: "حذف",
    uploadFile: "رفع ملف أو صورة"
  },
  en: {
    appName: "Advanced AI Assistant",
    appSubtitle: "Next-gen interactive platform with context memory and advanced capabilities",
    newChat: "New Chat",
    conversations: "Previous Conversations",
    settings: "System Settings",
    usageLogs: "Usage History & Analytics",
    learnedMemory: "Long-Term Memory",
    memoryDesc: "Information and preferences the system automatically learned about you during conversations to personalize your answers:",
    addCustomFact: "Add Fact Manually",
    factPlaceholder: "e.g., I am a web developer and I prefer clean code...",
    addBtn: "Add to Memory",
    noMemory: "No learned facts in memory yet. Start chatting and the system will auto-extract facts!",
    theme: "Visual Theme",
    dark: "Dark Mode (Slate)",
    light: "Light Mode (Pure)",
    language: "Interface Language",
    systemPrompt: "Custom System Instructions (Personality)",
    systemPromptPlaceholder: "e.g., Always reply concisely with a helpful and technical tone...",
    tempLabel: "Creativity Level (Temperature)",
    clearHistory: "Clear All History",
    clearHistoryConfirm: "Are you sure you want to delete all chats and memory? This cannot be undone!",
    typing: "Analyzing query and generating response...",
    chatPlaceholder: "Ask anything, request code assistance, or upload photos/files to analyze...",
    noChats: "No previous chats found. Create a new one to begin!",
    emptyChatTitle: "Welcome to the Professional AI Workspace",
    emptyChatSubtitle: "An integrated portal combining Natural Language Processing, Continuous Learning Memory, and Multimodal Comprehension.",
    quickPrompts: [
      "Explain cloud computing conceptually in simple terms",
      "Write a TypeScript function to debounce an API query.",
      "Suggest innovative graduation project ideas using Machine Learning",
      "Review a conceptual design of an offline-first mobile architecture."
    ],
    usageTitle: "System Usage Analytics",
    totalQueries: "Total Queries",
    filesAnalyzed: "Analyzed Files / Media",
    learnedFacts: "Stored Facts",
    logsTitle: "Registered Telemetry & Operations Logs",
    logAction: "Operation",
    logDetails: "Details",
    logTime: "Timestamp",
    codeAssistantTitle: "Programming & Code Assistant",
    codeAssistantDesc: "The system automatically parses code, renders it with syntactical highlight wrappers, and enables easy copy-pasting.",
    dragDropText: "Drag & drop files here or click to browse",
    selectedFiles: "Selected files:",
    imagePreview: "Image Preview",
    unsupportedFile: "Unsupported file type or exceeds size limit",
    saveSettings: "Save Settings",
    close: "Close",
    memoryCategory: "Category",
    manual: "Manual",
    auto: "Auto",
    delete: "Delete",
    uploadFile: "Upload file or image"
  }
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: typeof translations.en;
  isRtl: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('app_language');
    return (saved === 'ar' || saved === 'en') ? saved : 'ar';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('app_language', lang);
  };

  const t = translations[language];
  const isRtl = language === 'ar';

  useEffect(() => {
    // Adjust document direction
    document.documentElement.dir = isRtl ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language, isRtl]);

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, isRtl }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useTranslation = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useTranslation must be used within a LanguageProvider');
  }
  return context;
};
