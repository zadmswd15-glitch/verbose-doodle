import React from 'react';
import { 
  Plus, 
  MessageSquare, 
  Trash2, 
  Settings, 
  Brain, 
  BarChart2, 
  Globe, 
  User as UserIcon,
  Terminal,
  Share2,
  Mail
} from 'lucide-react';
import { useTranslation } from './LanguageContext';
import { ChatSession } from '../types';

interface SidebarProps {
  userId: string;
  sessions: ChatSession[];
  activeSessionId: string | null;
  setActiveSessionId: (id: string | null) => void;
  onNewChat: () => void;
  onDeleteSession: (id: string) => void;
  onOpenSettings: () => void;
  onOpenUsageLogs: () => void;
  onOpenMemory: () => void;
  onOpenConnections: () => void;
  onOpenExport: () => void;
  isPlaygroundActive: boolean;
  setIsPlaygroundActive: (active: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  userId,
  sessions,
  activeSessionId,
  setActiveSessionId,
  onNewChat,
  onDeleteSession,
  onOpenSettings,
  onOpenUsageLogs,
  onOpenMemory,
  onOpenConnections,
  onOpenExport,
  isPlaygroundActive,
  setIsPlaygroundActive
}) => {
  const { t, language, setLanguage } = useTranslation();

  return (
    <div className="w-80 h-full flex flex-col bg-slate-900 border-r border-slate-800 text-slate-100 font-sans select-none">
      {/* App Logo & Header */}
      <div className="p-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-900/30">
            <Brain className="w-6 h-6 text-white animate-pulse" />
          </div>
          <div>
            <h1 className="text-base font-bold text-slate-100 tracking-tight leading-none">
              {t.appName}
            </h1>
            <span className="text-[10px] text-slate-400 font-mono mt-1 block">
              v1.0.0 (Bilingual AI)
            </span>
          </div>
        </div>
      </div>

      {/* Primary Actions */}
      <div className="p-4">
        <button
          onClick={onNewChat}
          className="w-full py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm flex items-center justify-center gap-2 transition-all duration-200 shadow-md shadow-indigo-900/20 active:scale-[0.98] cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          {t.newChat}
        </button>
      </div>

      {/* Conversations List */}
      <div className="flex-1 overflow-y-auto px-3 py-2 space-y-1">
        <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider px-3 mb-2 block">
          {t.conversations}
        </span>
        
        {sessions.length === 0 ? (
          <div className="p-4 text-center text-xs text-slate-500 italic">
            {t.noChats}
          </div>
        ) : (
          sessions.map((session) => {
            const isActive = session.id === activeSessionId;
            return (
              <div
                key={session.id}
                className={`group relative flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 cursor-pointer ${
                  isActive 
                    ? 'bg-slate-800 text-white border-l-2 border-indigo-500' 
                    : 'text-slate-400 hover:bg-slate-800/50 hover:text-slate-200'
                }`}
                onClick={() => setActiveSessionId(session.id)}
              >
                <MessageSquare className={`w-4 h-4 shrink-0 ${isActive ? 'text-indigo-400' : 'text-slate-500'}`} />
                <span className="text-sm truncate pr-6 text-left w-full">
                  {session.title || 'Untitled Conversation'}
                </span>
                
                {/* Delete button (only visible on group hover) */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteSession(session.id);
                  }}
                  className="absolute right-2 opacity-0 group-hover:opacity-100 hover:text-rose-400 text-slate-500 p-1 rounded transition-opacity duration-150 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })
        )}
      </div>

      {/* Custom Utility Items */}
      <div className="px-3 py-2 border-t border-slate-800 space-y-1 bg-slate-900/60">
        <button
          onClick={() => setIsPlaygroundActive(!isPlaygroundActive)}
          className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm transition-all cursor-pointer ${
            isPlaygroundActive
              ? 'bg-indigo-600 hover:bg-indigo-500 text-white font-semibold shadow-md shadow-indigo-900/30'
              : 'text-slate-400 hover:bg-slate-800/70 hover:text-slate-200'
          }`}
        >
          <div className="flex items-center gap-3">
            <Terminal className="w-4 h-4 text-indigo-400" />
            <span>{language === 'ar' ? 'وضع المبرمج 🛠️' : 'Programmer Mode 🛠️'}</span>
          </div>
          {isPlaygroundActive && (
            <span className="text-[8px] bg-indigo-800 text-indigo-200 px-1.5 py-0.5 rounded font-bold uppercase tracking-widest animate-pulse">
              Live
            </span>
          )}
        </button>

        <button
          onClick={onOpenConnections}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-slate-400 hover:bg-slate-800/70 hover:text-slate-200 text-sm transition-all cursor-pointer"
        >
          <Globe className="w-4 h-4 text-emerald-400" />
          <span>{language === 'ar' ? 'بوابة الربط والخدمات' : 'Connections Hub'}</span>
        </button>

        <button
          onClick={onOpenExport}
          className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-indigo-200 bg-indigo-950/25 border border-indigo-500/20 hover:border-indigo-500/50 hover:bg-indigo-950/45 text-sm transition-all cursor-pointer font-semibold shadow-md shadow-indigo-950/10"
        >
          <Share2 className="w-4 h-4 text-indigo-400 shrink-0" />
          <span>{language === 'ar' ? 'تصدير البيانات والمزامنة 🚀' : 'Export & Sync Data 🚀'}</span>
        </button>

        <button
          onClick={onOpenMemory}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-slate-400 hover:bg-slate-800/70 hover:text-slate-200 text-sm transition-all cursor-pointer"
        >
          <Brain className="w-4 h-4 text-indigo-400" />
          <span>{t.learnedMemory}</span>
        </button>

        <button
          onClick={onOpenUsageLogs}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-slate-400 hover:bg-slate-800/70 hover:text-slate-200 text-sm transition-all cursor-pointer"
        >
          <BarChart2 className="w-4 h-4 text-emerald-400" />
          <span>{t.usageLogs}</span>
        </button>

        <button
          onClick={onOpenSettings}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-slate-400 hover:bg-slate-800/70 hover:text-slate-200 text-sm transition-all cursor-pointer"
        >
          <Settings className="w-4 h-4 text-amber-400" />
          <span>{t.settings}</span>
        </button>
      </div>

      {/* User Profile & Bilingual Toggle */}
      <div className="p-4 border-t border-slate-800 flex items-center justify-between gap-3 bg-slate-950">
        <div className="flex items-center gap-2 max-w-[60%]">
          <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300">
            <UserIcon className="w-4 h-4" />
          </div>
          <div className="truncate">
            <p className="text-xs font-semibold text-slate-300 truncate">
              {userId.substring(0, 8)}...
            </p>
            <span className="text-[9px] text-emerald-500 font-mono flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
              Secure Auth
            </span>
          </div>
        </div>

        {/* Beautiful RTL Language Toggle */}
        <button
          onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-800 bg-slate-900 hover:bg-slate-800 text-xs text-slate-300 hover:text-white transition-all cursor-pointer font-medium"
        >
          <Globe className="w-3.5 h-3.5 text-indigo-400" />
          <span>{language === 'ar' ? 'English' : 'العربية'}</span>
        </button>
      </div>
    </div>
  );
};
