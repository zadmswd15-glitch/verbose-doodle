import React, { useState, useEffect } from 'react';
import { 
  X, 
  Download, 
  Mail, 
  Check, 
  Lock, 
  Sparkles, 
  RefreshCw, 
  AlertCircle, 
  Database, 
  Brain, 
  FileText, 
  Share2, 
  User as UserIcon,
  Copy,
  Terminal,
  Clock
} from 'lucide-react';
import { useTranslation } from './LanguageContext';
import { ChatSession, LearnedKnowledge, UsageLog, UserSettings } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { db, auth, googleSignIn, getCachedAccessToken } from '../lib/firebase';
import { collection, query, orderBy, getDocs } from 'firebase/firestore';
import { sendEmailViaGmail } from '../lib/gmailService';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  sessions: ChatSession[];
  knowledge: LearnedKnowledge[];
  usageLogs: UsageLog[];
  settings: UserSettings;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  userId,
  sessions,
  knowledge,
  usageLogs,
  settings
}) => {
  const { language, isRtl } = useTranslation();
  
  // Gmail & Login States
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [accessToken, setAccessToken] = useState<string | null>(getCachedAccessToken());
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [recipientEmail, setRecipientEmail] = useState('');
  const [emailSubject, setEmailSubject] = useState('');
  
  // Toggle sections to export
  const [exportConversations, setExportConversations] = useState(true);
  const [exportMemory, setExportMemory] = useState(true);
  const [exportLogs, setExportLogs] = useState(true);

  // Status and logs
  const [isExporting, setIsExporting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [statusType, setStatusType] = useState<'success' | 'error' | 'info' | null>(null);

  // Sync logged in user from auth state
  useEffect(() => {
    const unsub = auth.onAuthStateChanged((user) => {
      setCurrentUser(user);
      if (user && user.email) {
        setRecipientEmail(user.email);
        setEmailSubject(
          isRtl 
            ? `تصدير بيانات المساعد الذكي - ${new Date().toLocaleDateString('ar-EG')}` 
            : `AI Workspace Deep Export - ${new Date().toLocaleDateString()}`
        );
      }
    });
    return () => unsub();
  }, [isOpen, isRtl]);

  // Google OAuth Login Trigger
  const handleGoogleLogin = async () => {
    setIsLoggingIn(true);
    setStatusMessage(null);
    try {
      const result = await googleSignIn();
      setCurrentUser(result.user);
      setAccessToken(result.token);
      if (result.user.email) {
        setRecipientEmail(result.user.email);
      }
      setStatusType('success');
      setStatusMessage(
        isRtl 
          ? `تم تسجيل الدخول بنجاح بصفتك: ${result.user.email}` 
          : `Signed in successfully as ${result.user.email}`
      );
    } catch (err: any) {
      console.error('Google Sign In Error:', err);
      setStatusType('error');
      setStatusMessage(
        isRtl 
          ? `فشل تسجيل الدخول: ${err.message}` 
          : `Login failed: ${err.message}`
      );
    } finally {
      setIsLoggingIn(false);
    }
  };

  // Compile all data into structured raw object
  const compileFullBackup = async () => {
    const fullBackup: any = {
      exportedAt: new Date().toISOString(),
      user: {
        id: userId,
        email: currentUser?.email || 'Anonymous',
        isGoogleAuthenticated: !!currentUser?.email
      },
      settings: {
        theme: settings.theme,
        language: settings.language,
        activeProvider: settings.activeProvider || 'gemini',
        memoryEnabled: settings.memoryEnabled
      },
      knowledgeBase: exportMemory ? knowledge.map(k => ({
        fact: k.fact,
        category: k.category,
        detectedAt: new Date(k.createdAt).toLocaleString()
      })) : [],
      usageLogs: exportLogs ? usageLogs.map(l => ({
        action: l.action,
        details: l.details,
        timestamp: new Date(l.timestamp).toLocaleString()
      })) : []
    };

    if (exportConversations) {
      const chatHistory = [];
      setStatusMessage(isRtl ? 'جاري تجميع أرشيف المحادثات بالكامل...' : 'Assembling full chat histories...');
      
      for (const sess of sessions) {
        try {
          const msgsRef = collection(db, 'users', userId, 'sessions', sess.id, 'messages');
          const snap = await getDocs(msgsRef);
          const messagesInSession: any[] = [];
          snap.forEach(docSnap => {
            const data = docSnap.data();
            messagesInSession.push({
              role: data.role,
              content: data.content,
              timestamp: new Date(data.timestamp).toLocaleString()
            });
          });
          
          // Sort messages by timestamp if they have it
          messagesInSession.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

          chatHistory.push({
            sessionTitle: sess.title || 'Untitled Conversation',
            created: new Date(sess.createdAt).toLocaleString(),
            messages: messagesInSession
          });
        } catch (e) {
          console.error(`Error loading session ${sess.id}`, e);
        }
      }
      fullBackup.conversations = chatHistory;
    }

    return fullBackup;
  };

  // Generate gorgeous responsive HTML template for Email body
  const generateEmailHtml = (data: any) => {
    const rtlStyle = isRtl ? 'direction: rtl; text-align: right;' : 'direction: ltr; text-align: left;';
    
    let html = `
      <div style="font-family: system-ui, -apple-system, sans-serif; background-color: #090d16; color: #e2e8f0; padding: 24px; max-width: 800px; margin: 0 auto; border-radius: 16px; border: 1px solid #1e293b; ${rtlStyle}">
        <!-- Header -->
        <div style="border-bottom: 2px solid #312e81; padding-bottom: 16px; margin-bottom: 24px; text-align: center;">
          <h1 style="color: #6366f1; margin: 0; font-size: 26px; font-weight: 800; letter-spacing: -0.5px;">🚀 ${isRtl ? 'تصدير البيانات والمساعد الذكي المتقدم' : 'Neural Workspace Deep Export'}</h1>
          <p style="color: #94a3b8; font-size: 14px; margin: 8px 0 0 0;">${isRtl ? 'تصدير كامل للذاكرة، الألعاب، المحادثات وإعدادات الكمبيوتر' : 'Comprehensive archive of Memory, Chat Sessions, and System Settings'}</p>
        </div>

        <!-- Meta Info -->
        <div style="background-color: #0f172a; border: 1px solid #1e293b; border-radius: 12px; padding: 16px; margin-bottom: 24px;">
          <table style="width: 100%; border-collapse: collapse; font-size: 13px; color: #94a3b8;">
            <tr>
              <td style="padding: 4px 0;"><strong>${isRtl ? 'المستخدم المصدِّر' : 'Exported User'}:</strong> ${data.user.email}</td>
              <td style="padding: 4px 0; text-align: right;"><strong>${isRtl ? 'التاريخ' : 'Date'}:</strong> ${new Date(data.exportedAt).toLocaleString()}</td>
            </tr>
            <tr>
              <td style="padding: 4px 0;"><strong>${isRtl ? 'معرف المستخدم' : 'User UUID'}:</strong> ${data.user.id}</td>
              <td style="padding: 4px 0; text-align: right;"><strong>${isRtl ? 'مزود الخدمة الأساسي' : 'Active Model Provider'}:</strong> ${data.settings.activeProvider.toUpperCase()}</td>
            </tr>
          </table>
        </div>
    `;

    // 1. Long term memory block
    if (exportMemory && data.knowledgeBase.length > 0) {
      html += `
        <div style="margin-bottom: 28px;">
          <h2 style="color: #c084fc; font-size: 18px; border-bottom: 1px solid #3b0764; padding-bottom: 6px; margin-bottom: 12px; display: flex; align-items: center; gap: 8px;">
            🧠 ${isRtl ? 'الذاكرة طويلة المدى وما أعرفه عنك وعن نفسي' : 'Long-Term Synaptic Memory & Learned Facts'}
          </h2>
          <div style="background-color: #120b24; border: 1px solid #4a148c; border-radius: 12px; padding: 16px;">
            <ul style="margin: 0; padding-left: 20px; color: #e9d5ff; line-height: 1.6;">
      `;
      data.knowledgeBase.forEach((kb: any) => {
        html += `<li style="margin-bottom: 8px;"><strong>[${kb.category.toUpperCase()}]</strong> ${kb.fact} <span style="font-size: 10px; color: #a21caf;">(${kb.detectedAt})</span></li>`;
      });
      html += `
            </ul>
          </div>
        </div>
      `;
    }

    // 2. Chat history / Conversations
    if (exportConversations && data.conversations && data.conversations.length > 0) {
      html += `
        <div style="margin-bottom: 28px;">
          <h2 style="color: #60a5fa; font-size: 18px; border-bottom: 1px solid #1e3a8a; padding-bottom: 6px; margin-bottom: 12px;">
            💬 ${isRtl ? 'أرشيف وتاريخ المحادثات التفصيلي' : 'Complete Conversational Log'}
          </h2>
      `;

      data.conversations.forEach((sess: any) => {
        html += `
          <div style="background-color: #0b1329; border: 1px solid #1e3a8a; border-radius: 12px; padding: 16px; margin-bottom: 16px;">
            <h3 style="color: #38bdf8; margin-top: 0; margin-bottom: 4px; font-size: 15px;">📁 ${sess.sessionTitle}</h3>
            <p style="color: #64748b; font-size: 11px; margin: 0 0 12px 0;">${isRtl ? 'تاريخ البدء' : 'Started'}: ${sess.created}</p>
            <div style="space-y: 8px;">
        `;

        sess.messages.forEach((msg: any) => {
          const isUser = msg.role === 'user';
          const bubbleBg = isUser ? '#1e1b4b' : '#111827';
          const senderName = isUser ? (isRtl ? 'أنت' : 'You') : (isRtl ? 'الذكاء الاصطناعي' : 'AI Assistant');
          const senderColor = isUser ? '#818cf8' : '#34d399';
          
          html += `
            <div style="background-color: ${bubbleBg}; border-radius: 8px; padding: 12px; margin-bottom: 8px; border-left: 3px solid ${senderColor};">
              <div style="font-weight: bold; font-size: 12px; color: ${senderColor}; margin-bottom: 4px;">${senderName} <span style="font-size: 9px; color: #64748b; font-weight: normal; margin-left: 8px;">(${msg.timestamp})</span></div>
              <div style="font-size: 13px; line-height: 1.5; color: #f1f5f9; white-space: pre-wrap;">${msg.content}</div>
            </div>
          `;
        });

        html += `
            </div>
          </div>
        `;
      });

      html += `</div>`;
    }

    // 3. Usage Log telemetry
    if (exportLogs && data.usageLogs && data.usageLogs.length > 0) {
      html += `
        <div style="margin-bottom: 28px;">
          <h2 style="color: #34d399; font-size: 18px; border-bottom: 1px solid #064e3b; padding-bottom: 6px; margin-bottom: 12px;">
            📊 ${isRtl ? 'سجل العمليات والتحليلات البرمجية' : 'Execution Telemetry & Interaction Logs'}
          </h2>
          <div style="background-color: #061c15; border: 1px solid #064e3b; border-radius: 12px; padding: 12px; overflow-x: auto;">
            <table style="width: 100%; border-collapse: collapse; font-size: 11px; font-family: monospace; color: #a7f3d0;">
              <thead>
                <tr style="border-bottom: 1px solid #064e3b; text-align: left; color: #34d399;">
                  <th style="padding: 6px;">${isRtl ? 'الحدث' : 'Event'}</th>
                  <th style="padding: 6px;">${isRtl ? 'التاريخ' : 'Timestamp'}</th>
                  <th style="padding: 6px;">${isRtl ? 'التفاصيل' : 'Details'}</th>
                </tr>
              </thead>
              <tbody>
      `;

      data.usageLogs.forEach((l: any) => {
        html += `
          <tr style="border-bottom: 1px solid #062f21;">
            <td style="padding: 6px; font-weight: bold;">${l.action}</td>
            <td style="padding: 6px; color: #6ee7b7; white-space: nowrap;">${l.timestamp}</td>
            <td style="padding: 6px; color: #d1fae5;">${l.details}</td>
          </tr>
        `;
      });

      html += `
              </tbody>
            </table>
          </div>
        </div>
      `;
    }

    // Footer
    html += `
        <div style="border-top: 1px solid #1e293b; padding-top: 16px; margin-top: 32px; text-align: center; font-size: 11px; color: #64748b;">
          <p>${isRtl ? 'تصدير آمن مشفر من مساعدك الذكي عبر السحاب' : 'This data was compiled securely and encrypted via Cloud Workspace APIs.'}</p>
          <p>&copy; 2026 AI Workspace Build Platform</p>
        </div>
      </div>
    `;

    return html;
  };

  // Direct send via Gmail REST API using Gmail service
  const handleSendEmail = async () => {
    if (!accessToken) {
      setStatusType('error');
      setStatusMessage(isRtl ? 'يرجى تسجيل الدخول باستخدام Google أولاً لتوليد الصلاحية.' : 'Please sign in with Google first to authenticate.');
      return;
    }

    if (!recipientEmail.trim()) {
      setStatusType('error');
      setStatusMessage(isRtl ? 'يرجى إدخال عنوان البريد الإلكتروني المستلم.' : 'Please provide a valid recipient email.');
      return;
    }

    setIsExporting(true);
    setStatusType('info');
    setStatusMessage(isRtl ? 'جاري تصدير وتجميع كافة الملفات والمحادثات...' : 'Assembling full workspace backup...');

    try {
      // 1. Compile the deep data payload
      const backupData = await compileFullBackup();

      // 2. Format HTML email body
      const emailHtml = generateEmailHtml(backupData);

      // 3. Dispatch using modular Gmail service
      setStatusMessage(isRtl ? 'جاري ربط اتصال Google Gmail الآمن للغرس والتحويل...' : 'Establishing Google Handshake and sending message...');
      const result = await sendEmailViaGmail(
        accessToken,
        recipientEmail,
        currentUser?.email || 'me',
        emailSubject,
        emailHtml
      );

      if (result.success) {
        setStatusType('success');
        setStatusMessage(
          isRtl 
            ? `تم إرسال كافة المحادثات والذكريات بنجاح إلى: ${recipientEmail} 🎉` 
            : `Workspace data and chat sessions successfully dispatched to: ${recipientEmail} 🎉`
        );
      } else {
        throw new Error(result.error || 'Gmail dispatch rejected');
      }

    } catch (err: any) {
      console.error('Gmail Sending Error:', err);
      setStatusType('error');
      setStatusMessage(
        isRtl 
          ? `فشل إرسال البريد الإلكتروني: ${err.message}. قد تحتاج لإعادة تسجيل الدخول لمنح الصلاحيات.` 
          : `Failed to dispatch email: ${err.message}. You may need to login again to renew OAuth permission.`
      );
    } finally {
      setIsExporting(false);
    }
  };

  // Direct download option for JSON backup file
  const handleDownloadBackup = async () => {
    setIsExporting(true);
    setStatusType('info');
    setStatusMessage(isRtl ? 'جاري بناء ملف التصدير الكود البرمجي...' : 'Generating JSON archive...');

    try {
      const backupData = await compileFullBackup();
      const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `neural_workspace_export_${Date.now()}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setStatusType('success');
      setStatusMessage(isRtl ? 'تم تصدير وتنزيل ملف النسخ الاحتياطي بنجاح! 💾' : 'Backup JSON file downloaded successfully! 💾');
    } catch (err: any) {
      console.error(err);
      setStatusType('error');
      setStatusMessage(isRtl ? 'فشل التنزيل المباشر للملف' : 'Download failed.');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden text-slate-100 flex flex-col max-h-[92vh]"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-900/50">
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400">
                  <Share2 className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h2 className="text-sm font-extrabold uppercase tracking-wider font-mono">
                    {isRtl ? 'تصدير البيانات الفوري وإرسال الأرشيف 🛠️' : 'EXPORT HUB / NEURAL TELEPORT 🛠️'}
                  </h2>
                  <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                    {isRtl ? 'تصدير وإرسال المحادثات والذكريات إلى بريدك أو أي شخص' : 'Securely backup and dispatch workspace assets and chat history'}
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="text-slate-400 hover:text-white transition-colors p-1.5 rounded-lg hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content Area */}
            <div className="flex-1 overflow-y-auto p-6 space-y-5">
              
              {/* Step 1: Login Block */}
              <div className="border border-slate-800/80 rounded-2xl p-4 bg-slate-950/40 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800/50 pb-2">
                  <span className="text-xs font-bold text-slate-300 flex items-center gap-2">
                    <Lock className="w-3.5 h-3.5 text-indigo-400" />
                    {isRtl ? 'الخطوة 1: التحقق وتسجيل الدخول بحساب Google' : 'Step 1: Google Identity & Permission Check'}
                  </span>
                  {currentUser?.email ? (
                    <span className="text-[9px] font-mono font-bold text-emerald-400 bg-emerald-950/40 border border-emerald-900/50 px-2 py-0.5 rounded-full">
                      {isRtl ? 'متصل ومحقق' : 'Verified'}
                    </span>
                  ) : (
                    <span className="text-[9px] font-mono font-bold text-amber-500 bg-amber-950/20 border border-amber-900/30 px-2 py-0.5 rounded-full animate-pulse">
                      {isRtl ? 'مطلوب للمزامنة' : 'Login Required'}
                    </span>
                  )}
                </div>

                {!currentUser?.email ? (
                  <div className="py-2 text-center space-y-3">
                    <p className="text-[11px] text-slate-400 leading-relaxed max-w-sm mx-auto">
                      {isRtl 
                        ? 'يتطلب إرسال النسخ الاحتياطية وتاريخ المحادثات بريدياً عبر بروتوكول Google الآمن تسجيل الدخول.' 
                        : 'Google Login is required so that everything can be securely packaged and routed through your own Gmail server.'}
                    </p>
                    <button
                      onClick={handleGoogleLogin}
                      disabled={isLoggingIn}
                      className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all cursor-pointer shadow-lg active:scale-95 disabled:bg-slate-800 disabled:text-slate-500"
                    >
                      {isLoggingIn ? <RefreshCw className="w-4 h-4 animate-spin" /> : <UserIcon className="w-4 h-4" />}
                      {isRtl ? 'تسجيل الدخول باستخدام حساب جوجل' : 'Sign In with Google Account'}
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center justify-between bg-slate-950 border border-slate-900 p-3 rounded-xl">
                    <div className="flex items-center gap-3">
                      {currentUser.photoURL ? (
                        <img src={currentUser.photoURL} alt="Profile" className="w-8 h-8 rounded-full border border-indigo-500/40" referrerPolicy="no-referrer" />
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-slate-300">
                          <UserIcon className="w-4 h-4" />
                        </div>
                      )}
                      <div>
                        <p className="text-xs font-bold text-slate-200">{currentUser.displayName || 'Google User'}</p>
                        <p className="text-[10px] text-slate-400 font-mono">{currentUser.email}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => auth.signOut().then(() => { setAccessToken(null); setCurrentUser(null); })}
                      className="text-[10px] text-rose-400 hover:text-rose-300 hover:underline cursor-pointer font-mono"
                    >
                      {isRtl ? 'خروج' : 'Logout'}
                    </button>
                  </div>
                )}
              </div>

              {/* Step 2: Choose Data Checklist */}
              <div className="space-y-3">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block font-mono">
                  {isRtl ? 'الخطوة 2: اختر البيانات والملفات للتصدير' : 'Step 2: Choose Datasets for Export'}
                </span>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <button
                    onClick={() => setExportConversations(!exportConversations)}
                    className={`p-3 rounded-2xl border text-left flex flex-col justify-between h-24 transition-all cursor-pointer ${
                      exportConversations 
                        ? 'bg-indigo-950/20 text-indigo-100 border-indigo-500/50' 
                        : 'bg-slate-950/40 text-slate-500 border-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <FileText className={`w-4 h-4 ${exportConversations ? 'text-indigo-400' : 'text-slate-500'}`} />
                      <div className={`w-2.5 h-2.5 rounded-full ${exportConversations ? 'bg-indigo-400 animate-pulse' : 'bg-slate-800'}`}></div>
                    </div>
                    <div>
                      <span className="text-xs font-bold block">{isRtl ? 'كافة المحادثات' : 'All Conversations'}</span>
                      <span className="text-[9px] text-slate-400 block mt-0.5">{sessions.length} {isRtl ? 'جلسة نشطة' : 'chat sessions'}</span>
                    </div>
                  </button>

                  <button
                    onClick={() => setExportMemory(!exportMemory)}
                    className={`p-3 rounded-2xl border text-left flex flex-col justify-between h-24 transition-all cursor-pointer ${
                      exportMemory 
                        ? 'bg-purple-950/20 text-purple-100 border-purple-500/50' 
                        : 'bg-slate-950/40 text-slate-500 border-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <Brain className={`w-4 h-4 ${exportMemory ? 'text-purple-400' : 'text-slate-500'}`} />
                      <div className={`w-2.5 h-2.5 rounded-full ${exportMemory ? 'bg-purple-400 animate-pulse' : 'bg-slate-800'}`}></div>
                    </div>
                    <div>
                      <span className="text-xs font-bold block">{isRtl ? 'الذاكرة الذكية' : 'Knowledge & Memory'}</span>
                      <span className="text-[9px] text-slate-400 block mt-0.5">{knowledge.length} {isRtl ? 'تفاصيل ومعلومات' : 'learned facts'}</span>
                    </div>
                  </button>

                  <button
                    onClick={() => setExportLogs(!exportLogs)}
                    className={`p-3 rounded-2xl border text-left flex flex-col justify-between h-24 transition-all cursor-pointer ${
                      exportLogs 
                        ? 'bg-emerald-950/20 text-emerald-100 border-emerald-500/50' 
                        : 'bg-slate-950/40 text-slate-500 border-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <Database className={`w-4 h-4 ${exportLogs ? 'text-emerald-400' : 'text-slate-500'}`} />
                      <div className={`w-2.5 h-2.5 rounded-full ${exportLogs ? 'bg-emerald-400 animate-pulse' : 'bg-slate-800'}`}></div>
                    </div>
                    <div>
                      <span className="text-xs font-bold block">{isRtl ? 'سجل العمليات والتحليلات' : 'Activity & Telemetry'}</span>
                      <span className="text-[9px] text-slate-400 block mt-0.5">{usageLogs.length} {isRtl ? 'عملية برمجية' : 'operation logs'}</span>
                    </div>
                  </button>
                </div>
              </div>

              {/* Status Notifications Display */}
              {statusMessage && (
                <div className={`p-3.5 rounded-xl text-xs flex items-start gap-2.5 border font-mono ${
                  statusType === 'success' 
                    ? 'bg-emerald-950/30 border-emerald-900/50 text-emerald-400' 
                    : statusType === 'error'
                    ? 'bg-rose-950/30 border-rose-900/50 text-rose-400'
                    : 'bg-indigo-950/30 border-indigo-900/50 text-indigo-400'
                }`}>
                  {statusType === 'success' ? (
                    <Check className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
                  ) : statusType === 'error' ? (
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
                  ) : (
                    <RefreshCw className="w-4 h-4 shrink-0 mt-0.5 text-indigo-400 animate-spin" />
                  )}
                  <span>{statusMessage}</span>
                </div>
              )}

              {/* Action 1: Email Sending Box */}
              <div className="border border-slate-800/80 rounded-2xl p-5 bg-slate-950/20 space-y-4">
                <span className="text-xs font-bold text-indigo-300 flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  {isRtl ? 'الإرسال المباشر عبر Google Gmail (إلى أي شخص)' : 'Instant Dispatch via Gmail API'}
                </span>
                
                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                      {isRtl ? 'البريد الإلكتروني للمستلم (يمكنك الإرسال لنفسك أو لأي شخص)' : 'Recipient Email Address (Send to Anyone)'}
                    </label>
                    <input
                      type="email"
                      value={recipientEmail}
                      onChange={(e) => setRecipientEmail(e.target.value)}
                      placeholder="example@gmail.com"
                      className="w-full text-xs bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                      disabled={!currentUser?.email || isExporting}
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                      {isRtl ? 'موضوع الرسالة البريدية' : 'Email Subject Line'}
                    </label>
                    <input
                      type="text"
                      value={emailSubject}
                      onChange={(e) => setEmailSubject(e.target.value)}
                      placeholder={isRtl ? 'موضوع البريد الإلكتروني...' : 'E.g., Complete backup...'}
                      className="w-full text-xs bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                      disabled={!currentUser?.email || isExporting}
                    />
                  </div>

                  <button
                    onClick={handleSendEmail}
                    disabled={!currentUser?.email || isExporting || !recipientEmail}
                    className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-[0.99] shadow-lg shadow-indigo-900/10"
                  >
                    {isExporting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Mail className="w-3.5 h-3.5" />}
                    {isRtl ? 'إرسال التصدير بريدياً عبر تلي بورت 🚀' : 'Transmit deep workspace data to email 🚀'}
                  </button>
                </div>
              </div>

            </div>

            {/* Footer with JSON Download */}
            <div className="flex items-center justify-between p-5 border-t border-slate-800 bg-slate-950/40">
              <span className="text-[10px] text-indigo-400 font-mono flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                {isRtl ? 'تصدير زمني تراكمي كامل' : 'All-Time Synaptic Backup'}
              </span>
              <div className="flex items-center gap-2.5">
                <button
                  onClick={handleDownloadBackup}
                  disabled={isExporting}
                  className="px-4 py-2 rounded-xl border border-slate-800 bg-slate-950/60 hover:bg-slate-950 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  {isRtl ? 'تنزيل ملف JSON' : 'Download JSON file'}
                </button>
                <button
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold transition-colors cursor-pointer"
                >
                  {isRtl ? 'إغلاق' : 'Close'}
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
