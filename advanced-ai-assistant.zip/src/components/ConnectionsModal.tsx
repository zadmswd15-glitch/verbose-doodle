import React, { useState, useEffect } from 'react';
import { 
  X, 
  Settings, 
  Key, 
  Video, 
  MessageSquare, 
  Send, 
  Plus, 
  Check, 
  RefreshCw, 
  Sparkles, 
  AlertCircle,
  HelpCircle,
  Smartphone,
  Globe
} from 'lucide-react';
import { useTranslation } from './LanguageContext';
import { UserSettings } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { googleSignIn, getCachedAccessToken } from '../lib/firebase';

interface ConnectionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: UserSettings;
  onSaveSettings: (settings: UserSettings) => void;
}

export const ConnectionsModal: React.FC<ConnectionsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings
}) => {
  const { language, isRtl } = useTranslation();
  
  // Local settings for connection keys and selected provider
  const [activeProvider, setActiveProvider] = useState<'gemini' | 'openai' | 'groq' | 'nanabanana'>(
    settings.activeProvider || 'gemini'
  );
  const [openaiKey, setOpenaiKey] = useState(settings.openaiKey || '');
  const [groqKey, setGroqKey] = useState(settings.groqKey || '');
  const [telegramToken, setTelegramToken] = useState(settings.telegramToken || '');
  const [geminiKey, setGeminiKey] = useState(settings.geminiKey || '');
  const [nanabananaKey, setNanabananaKey] = useState(settings.nanabananaKey || '');
  const [openaiModel, setOpenaiModel] = useState(settings.openaiModel || 'gpt-4o-mini');
  const [groqModel, setGroqModel] = useState(settings.groqModel || 'llama-3.3-70b-versatile');
  const [geminiModel, setGeminiModel] = useState(settings.geminiModel || 'gemini-3.5-flash');

  // Google Workspace States
  const [googleUser, setGoogleUser] = useState<any>(null);
  const [accessToken, setAccessToken] = useState<string | null>(getCachedAccessToken());
  const [isSigningIn, setIsSigningIn] = useState(false);
  
  // Meet States
  const [meetLink, setMeetLink] = useState<string | null>(null);
  const [isCreatingMeet, setIsCreatingMeet] = useState(false);
  const [meetError, setMeetError] = useState<string | null>(null);

  // Chat States
  const [chatSpaces, setChatSpaces] = useState<any[]>([]);
  const [isLoadingSpaces, setIsLoadingSpaces] = useState(false);
  const [newSpaceName, setNewSpaceName] = useState('');
  const [isCreatingSpace, setIsCreatingSpace] = useState(false);
  const [selectedSpaceId, setSelectedSpaceId] = useState(settings.selectedChatSpace || '');
  const [chatMessage, setChatMessage] = useState('');
  const [isSendingMessage, setIsSendingMessage] = useState(false);
  const [chatStatus, setChatStatus] = useState<string | null>(null);

  // Telegram bot state info
  const [telegramBotInfo, setTelegramBotInfo] = useState<any>(null);
  const [isLoadingTelegram, setIsLoadingTelegram] = useState(false);
  const [telegramError, setTelegramError] = useState<string | null>(null);

  // Sync token from memory cache and settings states if they update
  useEffect(() => {
    if (isOpen) {
      setActiveProvider(settings.activeProvider || 'gemini');
      setOpenaiKey(settings.openaiKey || '');
      setGroqKey(settings.groqKey || '');
      setTelegramToken(settings.telegramToken || '');
      setGeminiKey(settings.geminiKey || '');
      setNanabananaKey(settings.nanabananaKey || '');
      setOpenaiModel(settings.openaiModel || 'gpt-4o-mini');
      setGroqModel(settings.groqModel || 'llama-3.3-70b-versatile');
      setGeminiModel(settings.geminiModel || 'gemini-3.5-flash');
      setAccessToken(getCachedAccessToken());
    }
  }, [isOpen, settings]);

  // Load spaces if connected
  useEffect(() => {
    if (accessToken) {
      fetchChatSpaces();
    }
  }, [accessToken]);

  // Check Telegram Bot status
  const checkTelegramStatus = async (tokenToCheck: string) => {
    if (!tokenToCheck) return;
    setIsLoadingTelegram(true);
    setTelegramError(null);
    try {
      const res = await fetch(`https://api.telegram.org/bot${tokenToCheck}/getMe`);
      const data = await res.json();
      if (data.ok) {
        setTelegramBotInfo(data.result);
      } else {
        setTelegramError(isRtl ? 'توكن غير صالح للروبوت' : 'Invalid Bot Token');
        setTelegramBotInfo(null);
      }
    } catch (err) {
      setTelegramError(isRtl ? 'خطأ في الاتصال بتليجرام' : 'Telegram Connection Error');
      setTelegramBotInfo(null);
    } finally {
      setIsLoadingTelegram(false);
    }
  };

  useEffect(() => {
    if (telegramToken) {
      checkTelegramStatus(telegramToken);
    }
  }, []);

  // Google Sign-In Handler
  const handleGoogleConnect = async () => {
    setIsSigningIn(true);
    try {
      const result = await googleSignIn();
      setGoogleUser(result.user);
      setAccessToken(result.token);
    } catch (err: any) {
      console.error('Google Connect Error:', err);
      alert(isRtl ? `فشل الاتصال بحساب جوجل: ${err.message}` : `Failed to connect Google Workspace: ${err.message}`);
    } finally {
      setIsSigningIn(false);
    }
  };

  // Google Meet: Generate Meeting Link
  const handleCreateMeet = async () => {
    if (!accessToken) return;
    setIsCreatingMeet(true);
    setMeetError(null);
    setMeetLink(null);

    try {
      // Create a meeting space using REST Google Meet API v2
      const res = await fetch('https://meet.googleapis.com/v2/spaces', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error?.message || 'Unknown Meet API error');
      }

      const data = await res.json();
      if (data.meetingUri) {
        setMeetLink(data.meetingUri);
      } else if (data.meetingCode) {
        setMeetLink(`https://meet.google.com/${data.meetingCode}`);
      } else {
        throw new Error('No meetingUri returned');
      }
    } catch (err: any) {
      console.error(err);
      setMeetError(isRtl ? `فشل إنشاء مساحة Meet: ${err.message}` : `Meet creation failed: ${err.message}`);
    } finally {
      setIsCreatingMeet(false);
    }
  };

  // Google Chat: Fetch Spaces
  const fetchChatSpaces = async () => {
    if (!accessToken) return;
    setIsLoadingSpaces(true);
    try {
      const res = await fetch('https://chat.googleapis.com/v1/spaces', {
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });
      if (res.ok) {
        const data = await res.json();
        setChatSpaces(data.spaces || []);
      }
    } catch (err) {
      console.error('Fetch Spaces Error:', err);
    } finally {
      setIsLoadingSpaces(false);
    }
  };

  // Google Chat: Create a New Space
  const handleCreateSpace = async () => {
    if (!accessToken || !newSpaceName.trim()) return;
    setIsCreatingSpace(true);
    try {
      const res = await fetch('https://chat.googleapis.com/v1/spaces', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          spaceType: 'SPACE',
          displayName: newSpaceName
        })
      });

      if (!res.ok) {
        const errText = await res.text();
        throw new Error(errText);
      }

      const data = await res.json();
      setNewSpaceName('');
      await fetchChatSpaces();
      setSelectedSpaceId(data.name);
    } catch (err: any) {
      console.error('Create Space Error:', err);
      alert(isRtl ? 'عذراً، يرجى تفعيل واجهة Chat API في الكونسول لتتمكن من إنشاء المساحات.' : 'Please ensure Google Chat API is enabled in your GCP project console.');
    } finally {
      setIsCreatingSpace(false);
    }
  };

  // Google Chat: Post a Message to Selected Space
  const handleSendMessageToChat = async () => {
    if (!accessToken || !selectedSpaceId || !chatMessage.trim()) return;
    
    // Explicit user confirmation for sending messages on their behalf per instructions
    const confirmSend = window.confirm(
      isRtl 
        ? `هل توافق على إرسال الرسالة إلى مساحة Google Chat المحددة؟`
        : `Are you sure you want to send this message to Google Chat on your behalf?`
    );
    if (!confirmSend) return;

    setIsSendingMessage(true);
    setChatStatus(null);
    try {
      const res = await fetch(`https://chat.googleapis.com/v1/${selectedSpaceId}/messages`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          text: chatMessage
        })
      });

      if (res.ok) {
        setChatMessage('');
        setChatStatus(isRtl ? 'تم إرسال الرسالة بنجاح لـ Google Chat! 🎉' : 'Message successfully posted to Google Chat! 🎉');
      } else {
        const errData = await res.json();
        setChatStatus(isRtl ? `فشل الإرسال: ${errData.error?.message || 'خطأ غير معروف'}` : `Failed to post: ${errData.error?.message}`);
      }
    } catch (err: any) {
      setChatStatus(`Error: ${err.message}`);
    } finally {
      setIsSendingMessage(false);
    }
  };

  const handleSave = () => {
    onSaveSettings({
      ...settings,
      activeProvider,
      openaiKey,
      groqKey,
      telegramToken,
      geminiKey,
      nanabananaKey,
      selectedChatSpace: selectedSpaceId,
      openaiModel,
      groqModel,
      geminiModel
    });
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm"
          />

          {/* Modal Content */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden text-slate-100 flex flex-col max-h-[90vh]"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-900/50">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-indigo-500 animate-pulse" />
                <h2 className="text-base font-bold tracking-tight">
                  {isRtl ? 'بوابة الربط والخدمات الذكية (Connections)' : 'Workspace & API Integrations Hub'}
                </h2>
              </div>
              <button
                onClick={onClose}
                className="text-slate-400 hover:text-white transition-colors p-1 rounded-lg hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Content */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              
              {/* Active AI Model Provider Toggle */}
              <div className="space-y-3">
                <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider block">
                  {isRtl ? 'مزود المحادثة الرئيسي' : 'Core LLM Chat Provider'}
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { id: 'gemini', label: 'Gemini / AI Studio' },
                    { id: 'openai', label: 'OpenAI GPT' },
                    { id: 'groq', label: 'Groq LLaMA' },
                    { id: 'nanabanana', label: 'Nana Banana 🍌' }
                  ].map((p) => (
                    <button
                      key={p.id}
                      onClick={() => setActiveProvider(p.id as any)}
                      className={`p-3 rounded-xl border text-xs font-semibold flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                        activeProvider === p.id
                          ? 'bg-indigo-600 text-white border-indigo-400 shadow-md shadow-indigo-900/20'
                          : 'bg-slate-950/40 text-slate-400 border-slate-800/80 hover:text-slate-200 hover:bg-slate-950/80'
                      }`}
                    >
                      <span className="truncate">{p.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* SECTION: Google Workspace Integrations */}
              <div className="border border-slate-800/80 rounded-2xl p-5 bg-slate-950/30 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800/60 pb-3">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
                      <Globe className="w-4 h-4" />
                    </div>
                    <span className="text-xs font-bold text-slate-200">
                      {isRtl ? 'جوجل وورك سبيس (Meet & Chat)' : 'Google Workspace Integrations'}
                    </span>
                  </div>
                  {accessToken ? (
                    <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-900/30">
                      {isRtl ? 'متصل بنجاح' : 'Workspace Connected'}
                    </span>
                  ) : (
                    <span className="text-[10px] font-mono text-slate-500">
                      {isRtl ? 'غير متصل' : 'Not Connected'}
                    </span>
                  )}
                </div>

                {!accessToken ? (
                  <div className="py-4 text-center space-y-4">
                    <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                      {isRtl
                        ? 'قم بربط حساب Google لتفعيل ميزات إنشاء غرف اجتماعات Google Meet الفورية، والمحادثة المباشرة مع مساحات Google Chat التابعة لمؤسستك.'
                        : 'Connect your Google account to access on-demand Google Meet spaces and interact with your organization\'s Google Chat channels.'}
                    </p>
                    <button
                      onClick={handleGoogleConnect}
                      disabled={isSigningIn}
                      className="gsi-material-button mx-auto shadow-lg hover:shadow-indigo-500/5"
                    >
                      <div className="gsi-material-button-state"></div>
                      <div className="gsi-material-button-content-wrapper">
                        <div className="gsi-material-button-icon">
                          <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" style={{ display: 'block' }}>
                            <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                            <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                            <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                            <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                            <path fill="none" d="M0 0h48v48H0z"></path>
                          </svg>
                        </div>
                        <span className="gsi-material-button-contents">
                          {isSigningIn 
                            ? (isRtl ? 'جاري الاتصال...' : 'Connecting...') 
                            : (isRtl ? 'ربط خدمات Google Workspace' : 'Connect Google Workspace')}
                        </span>
                      </div>
                    </button>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {/* Google Meet Widget */}
                    <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800 space-y-3">
                      <div className="flex items-center gap-2 text-indigo-400">
                        <Video className="w-4 h-4" />
                        <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                          Google Meet Generator
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500">
                        {isRtl 
                          ? 'أنشئ روابط غرف اجتماعات Google Meet فورية بلمسة واحدة.' 
                          : 'Instantly provision ready-to-join Google Meet spaces with a single click.'}
                      </p>
                      
                      <div className="flex items-center gap-3">
                        <button
                          onClick={handleCreateMeet}
                          disabled={isCreatingMeet}
                          className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium flex items-center gap-1.5 shadow-md transition-all cursor-pointer"
                        >
                          {isCreatingMeet ? (
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <Video className="w-3.5 h-3.5" />
                          )}
                          {isRtl ? 'توليد رابط اجتماع جديد' : 'Generate Meet Link'}
                        </button>

                        {meetLink && (
                          <div className="flex-1 flex items-center justify-between bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-lg">
                            <span className="text-xs font-mono text-emerald-400 truncate select-all">{meetLink}</span>
                            <a 
                              href={meetLink} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="text-[10px] bg-indigo-900/40 hover:bg-indigo-950 text-indigo-300 px-2.5 py-1 rounded border border-indigo-800/40"
                            >
                              {isRtl ? 'انضمام' : 'Join'}
                            </a>
                          </div>
                        )}
                      </div>
                      {meetError && (
                        <p className="text-[10px] text-rose-400 bg-rose-950/20 px-3 py-1.5 rounded-lg border border-rose-900/30 flex items-center gap-1.5">
                          <AlertCircle className="w-3.5 h-3.5" />
                          {meetError}
                        </p>
                      )}
                    </div>

                    {/* Google Chat Space Controller */}
                    <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800 space-y-4">
                      <div className="flex items-center gap-2 text-indigo-400">
                        <MessageSquare className="w-4 h-4" />
                        <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                          Google Chat Controller
                        </span>
                      </div>
                      
                      {/* Select Existing Space */}
                      <div className="space-y-1.5">
                        <label className="text-[11px] text-slate-400 block font-semibold">
                          {isRtl ? 'اختر مساحة Chat لإرسال الرسائل إليها:' : 'Select Space to send notifications:'}
                        </label>
                        <div className="flex gap-2">
                          <select
                            value={selectedSpaceId}
                            onChange={(e) => setSelectedSpaceId(e.target.value)}
                            className="flex-1 text-xs bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500 cursor-pointer"
                          >
                            <option value="">{isRtl ? '-- لم يتم تحديد مساحة --' : '-- No Space Selected --'}</option>
                            {chatSpaces.map((space) => (
                              <option key={space.name} value={space.name}>
                                {space.displayName || space.name}
                              </option>
                            ))}
                          </select>
                          <button
                            onClick={fetchChatSpaces}
                            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
                            title={isRtl ? 'تحديث' : 'Refresh'}
                          >
                            <RefreshCw className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Create New Space */}
                      <div className="space-y-1.5 pt-2 border-t border-slate-800/50">
                        <label className="text-[11px] text-slate-400 block font-semibold">
                          {isRtl ? 'إنشاء مساحة Chat جديدة:' : 'Create a brand new Google Chat Space:'}
                        </label>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={newSpaceName}
                            onChange={(e) => setNewSpaceName(e.target.value)}
                            placeholder={isRtl ? 'مثال: فريق الذكاء الاصطناعي...' : 'e.g., AI Engineering Team...'}
                            className="flex-1 text-xs bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                          />
                          <button
                            onClick={handleCreateSpace}
                            disabled={isCreatingSpace || !newSpaceName.trim()}
                            className="px-3 py-2 rounded-xl bg-indigo-600/90 hover:bg-indigo-600 text-white text-xs font-semibold flex items-center gap-1 cursor-pointer"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            {isRtl ? 'إنشاء' : 'Create'}
                          </button>
                        </div>
                      </div>

                      {/* Send test message */}
                      {selectedSpaceId && (
                        <div className="space-y-2 pt-2 border-t border-slate-800/50">
                          <label className="text-[11px] text-slate-400 block font-semibold">
                            {isRtl ? 'أرسل رسالة فورية إلى هذه المساحة:' : 'Post a Message to this Space:'}
                          </label>
                          <div className="flex gap-2">
                            <input
                              type="text"
                              value={chatMessage}
                              onChange={(e) => setChatMessage(e.target.value)}
                              placeholder={isRtl ? 'اكتب رسالتك لإرسالها لـ Chat...' : 'Type message to send directly to Google Chat...'}
                              className="flex-1 text-xs bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                            />
                            <button
                              onClick={handleSendMessageToChat}
                              disabled={isSendingMessage || !chatMessage.trim()}
                              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1 cursor-pointer"
                            >
                              <Send className="w-3.5 h-3.5 rotate-180" />
                              {isRtl ? 'إرسال' : 'Post'}
                            </button>
                          </div>
                          {chatStatus && (
                            <p className="text-[10px] text-emerald-400 font-medium">
                              {chatStatus}
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* SECTION: API & Bot Tokens Setup */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
                  <Key className="w-4 h-4 text-amber-500" />
                  <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                    {isRtl ? 'ربط مفاتيح البرمجيات (APIs & Tokens)' : 'Custom API Keys & Secure Tokens'}
                  </span>
                </div>

                <div className="space-y-4">
                  {/* Google AI Studio / Gemini Key */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-400 flex items-center justify-between">
                      <span>{isRtl ? 'مفتاح Gemini / Google AI Studio API' : 'Google AI Studio / Gemini API Key'}</span>
                      <span className="text-[10px] font-mono text-indigo-400">({isRtl ? 'اختياري، يسقط للمفتاح الافتراضي' : 'Optional, falls back to default'})</span>
                    </label>
                    <input
                      type="password"
                      value={geminiKey}
                      onChange={(e) => setGeminiKey(e.target.value)}
                      placeholder="AIzaSy..."
                      className="w-full text-xs bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                    />
                    
                    {/* Gemini Model Select */}
                    <div className="space-y-1 mt-1.5">
                      <label className="text-[10px] font-semibold text-slate-500 block">
                        {isRtl ? 'نموذج Gemini النشط' : 'Active Gemini Model'}
                      </label>
                      <select
                        value={geminiModel}
                        onChange={(e) => setGeminiModel(e.target.value)}
                        className="w-full text-xs bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-slate-300 focus:outline-none focus:border-indigo-500 cursor-pointer"
                      >
                        <option value="gemini-3.5-flash">gemini-3.5-flash (Default)</option>
                        <option value="gemini-2.5-flash">gemini-2.5-flash</option>
                        <option value="gemini-2.5-pro">gemini-2.5-pro</option>
                        <option value="gemini-1.5-flash">gemini-1.5-flash</option>
                        <option value="gemini-1.5-pro">gemini-1.5-pro</option>
                      </select>
                    </div>
                  </div>

                  {/* OpenAI GPT API Key */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-400">
                      {isRtl ? 'مفتاح OpenAI GPT API' : 'OpenAI GPT API Key'}
                    </label>
                    <input
                      type="password"
                      value={openaiKey}
                      onChange={(e) => setOpenaiKey(e.target.value)}
                      placeholder="sk-..."
                      className="w-full text-xs bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                    />

                    {/* OpenAI Model Select */}
                    <div className="space-y-1 mt-1.5">
                      <label className="text-[10px] font-semibold text-slate-500 block">
                        {isRtl ? 'نموذج GPT النشط' : 'Active GPT Model'}
                      </label>
                      <select
                        value={openaiModel}
                        onChange={(e) => setOpenaiModel(e.target.value)}
                        className="w-full text-xs bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-slate-300 focus:outline-none focus:border-indigo-500 cursor-pointer"
                      >
                        <option value="gpt-4o-mini">gpt-4o-mini (Default)</option>
                        <option value="gpt-4o">gpt-4o</option>
                        <option value="gpt-4-turbo">gpt-4-turbo</option>
                        <option value="o1-mini">o1-mini</option>
                        <option value="gpt-3.5-turbo">gpt-3.5-turbo</option>
                      </select>
                    </div>
                  </div>

                  {/* Groq API Key */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-400">
                      {isRtl ? 'مفتاح Groq API (LLaMA3 / Mixtral)' : 'Groq API Key (LLaMA3 / Mixtral)'}
                    </label>
                    <input
                      type="password"
                      value={groqKey}
                      onChange={(e) => setGroqKey(e.target.value)}
                      placeholder="gsk_..."
                      className="w-full text-xs bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                    />

                    {/* Groq Model Select */}
                    <div className="space-y-1 mt-1.5">
                      <label className="text-[10px] font-semibold text-slate-500 block">
                        {isRtl ? 'نموذج Groq النشط' : 'Active Groq Model'}
                      </label>
                      <select
                        value={groqModel}
                        onChange={(e) => setGroqModel(e.target.value)}
                        className="w-full text-xs bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-slate-300 focus:outline-none focus:border-indigo-500 cursor-pointer"
                      >
                        <option value="llama-3.3-70b-versatile">llama-3.3-70b-versatile (Default)</option>
                        <option value="llama-3.1-8b-instant">llama-3.1-8b-instant</option>
                        <option value="mixtral-8x7b-32768">mixtral-8x7b-32768</option>
                        <option value="gemma2-9b-it">gemma2-9b-it</option>
                      </select>
                    </div>
                  </div>

                  {/* Nana Banana Key */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-400">
                      {isRtl ? 'مفتاح Nana Banana API (نموذج الموز الترفيهي)' : 'Nana Banana API Key (Whimsical Yellow Model)'}
                    </label>
                    <input
                      type="password"
                      value={nanabananaKey}
                      onChange={(e) => setNanabananaKey(e.target.value)}
                      placeholder="banana-api-key..."
                      className="w-full text-xs bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  {/* Telegram Bot Token */}
                  <div className="space-y-2 p-4 rounded-xl border border-slate-800 bg-slate-950/20">
                    <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                      <span>{isRtl ? 'توكن روبوت تليجرام (Telegram Bot Token)' : 'Telegram Bot Token'}</span>
                      {telegramBotInfo && (
                        <span className="text-[10px] text-emerald-400 font-mono bg-emerald-950/40 px-2 py-0.5 rounded">
                          @{telegramBotInfo.username}
                        </span>
                      )}
                    </label>
                    <p className="text-[11px] text-slate-500 leading-relaxed">
                      {isRtl 
                        ? 'أدخل توكن BotFather لتليجرام للربط والتحقق من صحة اتصال الروبوت.' 
                        : 'Connect your Telegram BotToken from BotFather to link your AI and run a health status check.'}
                    </p>
                    <div className="flex gap-2">
                      <input
                        type="password"
                        value={telegramToken}
                        onChange={(e) => setTelegramToken(e.target.value)}
                        placeholder="123456:ABC-DEF1234ghIkl-zyx57W2v1u1"
                        className="flex-1 text-xs bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                      />
                      <button
                        onClick={() => checkTelegramStatus(telegramToken)}
                        disabled={isLoadingTelegram || !telegramToken}
                        className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl transition-all cursor-pointer flex items-center gap-1"
                      >
                        {isLoadingTelegram ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Smartphone className="w-3.5 h-3.5" />}
                        {isRtl ? 'فحص الاتصال' : 'Test'}
                      </button>
                    </div>
                    {telegramError && (
                      <p className="text-[10px] text-rose-400 font-medium">
                        {telegramError}
                      </p>
                    )}
                  </div>
                </div>
              </div>

            </div>

            {/* Footer */}
            <div className="flex items-center justify-between p-5 border-t border-slate-800 bg-slate-950/40">
              <span className="text-[10px] text-indigo-400 font-mono flex items-center gap-1 animate-pulse">
                <Sparkles className="w-3.5 h-3.5" />
                {isRtl ? 'بوابة تشفير آمنة' : 'Secure API Handshake'}
              </span>
              <div className="flex items-center gap-3">
                <button
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-xs font-medium transition-colors cursor-pointer"
                >
                  {isRtl ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  onClick={handleSave}
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium flex items-center gap-1.5 shadow-md shadow-indigo-900/10 transition-all cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" />
                  {isRtl ? 'حفظ وحفظ الاتصال' : 'Save Connections'}
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
