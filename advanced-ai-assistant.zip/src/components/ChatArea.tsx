import React, { useRef, useState, useEffect } from 'react';
import { 
  Send, 
  Paperclip, 
  X, 
  Check, 
  Copy, 
  Sparkles, 
  Brain, 
  Terminal, 
  ArrowDown, 
  FileText, 
  Image as ImageIcon,
  Mic,
  MicOff,
  AlertCircle,
  Search,
  Eye,
  ShieldCheck,
  ExternalLink
} from 'lucide-react';
import { useTranslation } from './LanguageContext';
import { Message, Attachment } from '../types';
import ReactMarkdown from 'react-markdown';
import { motion, AnimatePresence } from 'motion/react';

interface ChatAreaProps {
  messages: Message[];
  isGenerating: boolean;
  onSendMessage: (text: string, files: Attachment[]) => void;
  activeSessionId: string | null;
  onNewChat: () => void;
  activeProvider?: 'gemini' | 'openai' | 'groq' | 'nanabanana';
  settings?: any;
}

// Elegant wrapper for Code blocks inside Markdown to allow copy functionality
const CodeBlock: React.FC<{ children: string; language?: string }> = ({ children, language = 'javascript' }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(children);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="my-4 rounded-xl overflow-hidden border border-slate-800 bg-slate-950/90 font-mono text-xs shadow-lg shadow-black/20">
      <div className="bg-slate-900 px-4 py-2 flex items-center justify-between border-b border-slate-800/80 text-[10px] text-slate-400 font-sans select-none">
        <span className="flex items-center gap-1.5 font-semibold text-indigo-400">
          <Terminal className="w-3.5 h-3.5" />
          {language.toUpperCase()}
        </span>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1 hover:text-white transition-all bg-slate-950 hover:bg-slate-800 px-2.5 py-1 rounded-md border border-slate-800 cursor-pointer"
        >
          {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
          <span>{copied ? 'Copied' : 'Copy'}</span>
        </button>
      </div>
      <pre className="p-4 overflow-x-auto text-slate-200 leading-relaxed text-left" dir="ltr">
        <code>{children}</code>
      </pre>
    </div>
  );
};

/**
 * Decodes base64 text/code files safely supporting UTF-8 content.
 */
const getDecodedText = (dataUrl: string): string => {
  try {
    const base64Content = dataUrl.split(',')[1];
    if (!base64Content) return '';
    return decodeURIComponent(escape(window.atob(base64Content)));
  } catch (e) {
    try {
      return window.atob(dataUrl.split(',')[1] || '');
    } catch (err) {
      return 'Could not decode text file contents.';
    }
  }
};

interface AttachmentThumbnailProps {
  att: Attachment;
  onPreview: (att: Attachment) => void;
  onRemove?: () => void;
  isRtl: boolean;
  isVerified: boolean;
}

const AttachmentThumbnail: React.FC<AttachmentThumbnailProps> = ({
  att,
  onPreview,
  onRemove,
  isRtl,
  isVerified
}) => {
  const isImg = att.type.startsWith('image/');
  const isPdf = att.type === 'application/pdf' || att.name.toLowerCase().endsWith('.pdf');
  const isText = att.type.startsWith('text/') || /\.(txt|md|py|js|ts|tsx|jsx|html|css|json|csv|log|yaml|yml|ini|conf|sql|sh|bash)$/i.test(att.name);

  return (
    <div 
      className="relative group p-2 rounded-xl border border-slate-800 bg-slate-900/90 hover:bg-slate-900 hover:border-indigo-500/40 transition-all duration-200 flex items-center gap-2.5 min-w-[170px] max-w-[215px] select-none cursor-pointer hover:shadow-lg hover:shadow-indigo-950/10 active:scale-[0.98]"
      onClick={() => onPreview(att)}
    >
      {/* Visual Thumbnail */}
      {isImg ? (
        <div className="relative w-12 h-12 rounded-lg overflow-hidden border border-slate-800 shrink-0 bg-slate-950">
          <img 
            src={att.data} 
            alt={att.name} 
            className="w-full h-full object-cover group-hover:scale-105 transition-all duration-300" 
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-slate-950/20 group-hover:bg-slate-950/40 flex items-center justify-center transition-all">
            <Eye className="w-4 h-4 text-white opacity-0 group-hover:opacity-100 transition-all" />
          </div>
        </div>
      ) : isPdf ? (
        <div className="relative w-12 h-12 rounded-lg bg-rose-950/40 border border-rose-900/30 flex flex-col items-center justify-center shrink-0 text-rose-400 group-hover:bg-rose-950/60 transition-all">
          <FileText className="w-5 h-5" />
          <span className="text-[7px] font-mono font-bold bg-rose-600 text-white px-1 rounded-sm mt-0.5 scale-90">PDF</span>
          <div className="absolute inset-0 bg-slate-950/20 group-hover:bg-slate-950/40 flex items-center justify-center transition-all rounded-lg">
            <Eye className="w-4 h-4 text-white opacity-0 group-hover:opacity-100 transition-all" />
          </div>
        </div>
      ) : isText ? (
        <div className="relative w-12 h-12 rounded-lg bg-emerald-950/40 border border-emerald-900/30 flex flex-col items-center justify-center shrink-0 text-emerald-400 group-hover:bg-emerald-950/60 transition-all">
          <Terminal className="w-5 h-5" />
          <span className="text-[7px] font-mono font-bold bg-emerald-600 text-white px-1 rounded-sm mt-0.5 scale-90">CODE</span>
          <div className="absolute inset-0 bg-slate-950/20 group-hover:bg-slate-950/40 flex items-center justify-center transition-all rounded-lg">
            <Eye className="w-4 h-4 text-white opacity-0 group-hover:opacity-100 transition-all" />
          </div>
        </div>
      ) : (
        <div className="relative w-12 h-12 rounded-lg bg-slate-950 border border-slate-800 flex flex-col items-center justify-center shrink-0 text-indigo-400 group-hover:bg-slate-900 transition-all">
          <FileText className="w-5 h-5" />
          <span className="text-[6px] font-mono text-slate-500 uppercase truncate max-w-full px-0.5 mt-0.5">FILE</span>
          <div className="absolute inset-0 bg-slate-950/20 group-hover:bg-slate-950/40 flex items-center justify-center transition-all rounded-lg">
            <Eye className="w-4 h-4 text-white opacity-0 group-hover:opacity-100 transition-all" />
          </div>
        </div>
      )}

      {/* Info Panel */}
      <div className={`truncate flex-1 min-w-0 ${isRtl ? 'text-right' : 'text-left'}`}>
        <p className="text-[10px] font-semibold text-slate-200 truncate group-hover:text-white transition-all leading-snug">{att.name}</p>
        <div className="flex items-center gap-1.5 mt-0.5 flex-wrap justify-start">
          <span className="text-[8px] text-slate-500 font-mono">{(att.size / 1024).toFixed(0)} KB</span>
          {isVerified && (
            <span className="inline-flex items-center gap-0.5 text-[7px] text-emerald-400 font-bold bg-emerald-950/50 border border-emerald-900/40 px-1 py-0.2 rounded">
              <ShieldCheck className="w-2.5 h-2.5 text-emerald-400 shrink-0 animate-pulse" />
              <span>{isRtl ? 'مؤكد' : 'OK'}</span>
            </span>
          )}
        </div>
      </div>

      {/* Remove Button for Pre-Send Queue */}
      {onRemove && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          className="absolute -top-1.5 -right-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-full p-0.5 shadow-md transition-all active:scale-90 z-10"
        >
          <X className="w-2.5 h-2.5" />
        </button>
      )}
    </div>
  );
};

export const ChatArea: React.FC<ChatAreaProps> = ({
  messages,
  isGenerating,
  onSendMessage,
  activeSessionId,
  onNewChat,
  activeProvider = 'gemini',
  settings
}) => {
  const { t, isRtl } = useTranslation();
  const [inputText, setInputText] = useState('');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isDragActive, setIsDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [showScrollBottomBtn, setShowScrollBottomBtn] = useState(false);

  // Verification & Lightbox states
  const [previewFile, setPreviewFile] = useState<Attachment | null>(null);
  const [verifiedFiles, setVerifiedFiles] = useState<Set<string>>(new Set());

  // Web Speech API states
  const [isListening, setIsListening] = useState(false);
  const [recognition, setRecognition] = useState<any>(null);
  const [speechError, setSpeechError] = useState<string | null>(null);
  const [interimTranscript, setInterimTranscript] = useState('');

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const rec = new SpeechRecognition();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = isRtl ? 'ar-SA' : 'en-US';

      rec.onresult = (event: any) => {
        let finalTranscript = '';
        let interimText = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimText += event.results[i][0].transcript;
          }
        }
        if (finalTranscript) {
          setInputText(prev => prev + (prev.trim() ? ' ' : '') + finalTranscript);
        }
        setInterimTranscript(interimText);
      };

      rec.onerror = (event: any) => {
        console.error('Speech recognition error', event);
        setIsListening(false);
        setInterimTranscript('');
        if (event.error === 'not-allowed') {
          setSpeechError(isRtl 
            ? 'يرجى السماح للبرنامج بالوصول للميكروفون من إعدادات المتصفح.' 
            : 'Microphone permission blocked. Please enable mic access in your browser address bar.');
        } else if (event.error === 'no-speech') {
          // Transient warning or just ignore silent end
        } else {
          setSpeechError(isRtl 
            ? `حدث خطأ في قراءة الصوت: ${event.error}` 
            : `Speech recognition error: ${event.error}`);
        }
      };

      rec.onend = () => {
        setIsListening(false);
        setInterimTranscript('');
      };

      setRecognition(rec);
    }
  }, [isRtl]);

  const toggleListening = () => {
    if (!recognition) {
      alert(isRtl ? 'إدخال الصوت غير مدعوم في متصفحك الحالي.' : 'Speech Recognition is not supported in your browser.');
      return;
    }

    if (isListening) {
      recognition.stop();
      setIsListening(false);
    } else {
      try {
        setSpeechError(null);
        recognition.start();
        setIsListening(true);
      } catch (e) {
        console.error('Failed to start speech recognition', e);
      }
    }
  };

  // Auto-scroll logic
  const scrollToBottom = () => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isGenerating]);

  // Monitor scroll height to show/hide "Scroll to Bottom" badge
  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const target = e.currentTarget;
    const isAtBottom = target.scrollHeight - target.scrollTop <= target.clientHeight + 150;
    setShowScrollBottomBtn(!isAtBottom && messages.length > 2);
  };

  // Convert files to base64
  const processFile = (file: File) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      let mimeType = file.type || '';
      
      if (!mimeType) {
        const ext = file.name.split('.').pop()?.toLowerCase();
        if (ext) {
          const textExtensions = ['txt', 'md', 'py', 'js', 'ts', 'tsx', 'jsx', 'html', 'css', 'json', 'csv', 'log', 'yaml', 'yml', 'ini', 'conf', 'sql', 'sh', 'bash'];
          if (textExtensions.includes(ext)) {
            mimeType = 'text/plain';
          } else if (ext === 'pdf') {
            mimeType = 'application/pdf';
          } else if (['png', 'jpg', 'jpeg', 'webp', 'gif'].includes(ext)) {
            mimeType = `image/${ext === 'jpg' ? 'jpeg' : ext}`;
          } else {
            mimeType = 'application/octet-stream';
          }
        } else {
          mimeType = 'application/octet-stream';
        }
      }

      const newAttachment: Attachment = {
        name: file.name,
        type: mimeType,
        size: file.size,
        data: base64String
      };
      setAttachments(prev => [...prev, newAttachment]);
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      Array.from(e.target.files).forEach(processFile);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setIsDragActive(true);
    } else if (e.type === 'dragleave') {
      setIsDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);
    if (e.dataTransfer.files) {
      Array.from(e.dataTransfer.files).forEach(processFile);
    }
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const handleSend = () => {
    if (!inputText.trim() && attachments.length === 0) return;
    onSendMessage(inputText, attachments);
    setInputText('');
    setAttachments([]);
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const clickQuickPrompt = (promptText: string) => {
    setInputText(promptText);
  };

  return (
    <div 
      className="flex-1 h-full flex flex-col bg-slate-950 text-slate-100 font-sans relative overflow-hidden"
      onDragEnter={handleDrag}
      onDragOver={handleDrag}
      onDragLeave={handleDrag}
      onDrop={handleDrop}
    >
      {/* Background Drag Backdrop Overlay */}
      <AnimatePresence>
        {isDragActive && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-40 bg-indigo-950/80 backdrop-blur-md flex flex-col items-center justify-center border-4 border-dashed border-indigo-500 m-4 rounded-3xl"
          >
            <Paperclip className="w-16 h-16 text-indigo-400 animate-bounce" />
            <h3 className="text-xl font-bold mt-4 text-white">{t.dragDropText}</h3>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header Panel */}
      <div className="h-14 border-b border-slate-900/85 px-6 flex items-center justify-between bg-slate-950/80 backdrop-blur-sm z-15">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-indigo-500 animate-pulse"></div>
          <span className="text-xs font-mono font-bold text-indigo-400 uppercase tracking-widest">
            {activeProvider === 'openai' 
              ? (settings?.openaiModel || 'gpt-4o-mini') 
              : activeProvider === 'groq' 
              ? (settings?.groqModel || 'llama-3.3-70b-versatile')
              : activeProvider === 'nanabanana'
              ? 'Nana Banana 🍌'
              : (settings?.geminiModel || 'gemini-3.5-flash')}
          </span>
          <span className="text-xs text-slate-500">•</span>
          <span className="text-xs font-semibold text-slate-400">
            {isRtl ? 'بنية كاملة ذكية' : 'Full-stack Cognition'}
          </span>
        </div>

        <div className="flex items-center gap-4">
          <span className="text-[10px] text-emerald-500 font-mono bg-emerald-950/40 px-2.5 py-1 rounded-full border border-emerald-900/30 font-bold">
            {isRtl ? 'قاعدة بيانات متصلة' : 'Database Synced'}
          </span>
        </div>
      </div>

      {/* Messages Feed */}
      <div 
        className="flex-1 overflow-y-auto px-6 py-6 space-y-6 relative"
        onScroll={handleScroll}
      >
        {messages.length === 0 ? (
          /* Empty State Welcome Screen */
          <div className="h-full flex flex-col items-center justify-center max-w-lg mx-auto text-center space-y-6 mt-12">
            <div className="w-16 h-16 rounded-2xl bg-indigo-950 border border-indigo-900/40 flex items-center justify-center shadow-lg shadow-indigo-950/30">
              <Brain className="w-9 h-9 text-indigo-400" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-100 tracking-tight">
                {t.emptyChatTitle}
              </h2>
              <p className="text-xs text-slate-400 leading-relaxed mt-2.5">
                {t.emptyChatSubtitle}
              </p>
            </div>

            {/* Quick Prompt Suggestions */}
            <div className="grid grid-cols-2 gap-3 w-full pt-4">
              {t.quickPrompts.map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => clickQuickPrompt(p)}
                  className="p-3.5 text-right text-xs bg-slate-900/40 hover:bg-slate-900 hover:border-slate-800 border border-slate-900/80 rounded-2xl text-slate-400 hover:text-slate-100 transition-all duration-200 cursor-pointer font-sans leading-relaxed active:scale-[0.98]"
                >
                  {p}
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map((m) => {
            const isModel = m.role === 'model';
            return (
              <div 
                key={m.id}
                className={`flex gap-4 ${isModel ? 'justify-start' : 'justify-end'}`}
              >
                {/* Robot/User visual icons */}
                {isModel && (
                  <div className="w-8 h-8 rounded-lg bg-indigo-950/70 border border-indigo-900/30 flex items-center justify-center shadow-md select-none shrink-0 mt-1">
                    <Brain className="w-4 h-4 text-indigo-400" />
                  </div>
                )}

                <div className={`max-w-[85%] flex flex-col ${isModel ? 'items-start' : 'items-end'}`}>
                  {/* Attachments inside bubble */}
                  {m.attachments && m.attachments.length > 0 && (
                    <div className="flex gap-2 mb-2 flex-wrap justify-start">
                      {m.attachments.map((att, i) => (
                        <AttachmentThumbnail
                          key={i}
                          att={att}
                          onPreview={(file) => setPreviewFile(file)}
                          isRtl={isRtl}
                          isVerified={verifiedFiles.has(att.name + '-' + att.size)}
                        />
                      ))}
                    </div>
                  )}

                  {/* Text bubble */}
                  <div 
                    className={`px-5 py-3.5 rounded-2xl text-sm leading-relaxed border font-sans ${
                      isModel 
                        ? 'bg-slate-900/40 border-slate-900/80 text-slate-100 rounded-tl-sm' 
                        : 'bg-indigo-600 border-indigo-500 text-white rounded-tr-sm shadow-md shadow-indigo-950/10'
                    }`}
                  >
                    {isModel ? (
                      /* Rich Markdown for AI answer */
                      <div className="prose prose-invert prose-xs max-w-none text-right font-sans" dir={isRtl ? 'rtl' : 'ltr'}>
                        <ReactMarkdown
                          components={{
                            code({ node, className, children, ...props }) {
                              const match = /language-(\w+)/.exec(className || '');
                              return match ? (
                                <CodeBlock language={match[1]}>
                                  {String(children).replace(/\n$/, '')}
                                </CodeBlock>
                              ) : (
                                <code className="bg-slate-950 px-1.5 py-0.5 rounded text-indigo-400 font-mono text-xs" {...props}>
                                  {children}
                                </code>
                              );
                            }
                          }}
                        >
                          {m.content}
                        </ReactMarkdown>
                      </div>
                    ) : (
                      /* Plain text for user with simple formatting */
                      <p className="whitespace-pre-wrap text-right">{m.content}</p>
                    )}
                  </div>
                  
                  {/* Search Grounding Sources */}
                  {isModel && m.searchSources && m.searchSources.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1.5 justify-start">
                      {m.searchSources.map((src, i) => (
                        <a
                          key={i}
                          href={src.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 text-[10px] bg-slate-900 border border-slate-800 hover:border-indigo-500/50 hover:bg-slate-900 px-2.5 py-1 rounded-full text-indigo-400 hover:text-indigo-300 transition-all font-mono max-w-[220px]"
                        >
                          <Search className="w-3 h-3 text-indigo-500 shrink-0" />
                          <span className="truncate">{src.title}</span>
                        </a>
                      ))}
                    </div>
                  )}
                  
                  {/* Timestamp */}
                  <span className="text-[9px] text-slate-600 mt-1.5 font-mono select-none">
                    {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>
            );
          })
        )}

        {/* Typing indicator */}
        {isGenerating && (
          <div className="flex gap-4 justify-start">
            <div className="w-8 h-8 rounded-lg bg-indigo-950/70 border border-indigo-900/30 flex items-center justify-center shrink-0 mt-1 select-none">
              <Brain className="w-4 h-4 text-indigo-400 animate-spin" style={{ animationDuration: '4s' }} />
            </div>
            <div className="flex flex-col items-start max-w-[85%]">
              <div className="px-5 py-3.5 rounded-2xl bg-slate-900/40 border border-slate-900/80 rounded-tl-sm text-slate-400 flex items-center gap-3">
                <span className="text-xs">{t.typing}</span>
                <div className="flex gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce" style={{ animationDelay: '0ms' }}></span>
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce" style={{ animationDelay: '150ms' }}></span>
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce" style={{ animationDelay: '300ms' }}></span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Scroll dummy */}
        <div ref={scrollRef} />
      </div>

      {/* Floating Scroll-to-bottom badge */}
      {showScrollBottomBtn && (
        <button
          onClick={scrollToBottom}
          className="absolute bottom-28 left-1/2 -translate-x-1/2 z-20 px-3 py-1.5 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-lg shadow-black/30 cursor-pointer active:scale-95 transition-all"
        >
          <ArrowDown className="w-3.5 h-3.5" />
          {isRtl ? 'النزول للقاع' : 'Scroll to Bottom'}
        </button>
      )}

      {/* Footer input controls */}
      <div className="p-4 border-t border-slate-900/85 bg-slate-950">
        <div className="max-w-3xl mx-auto space-y-3">
          
          {/* File Previews Area */}
          {attachments.length > 0 && (
            <div className="flex gap-2.5 flex-wrap p-2.5 rounded-2xl border border-slate-900 bg-slate-950/70 shadow-inner">
              {attachments.map((att, i) => (
                <AttachmentThumbnail
                  key={i}
                  att={att}
                  onPreview={(file) => setPreviewFile(file)}
                  onRemove={() => removeAttachment(i)}
                  isRtl={isRtl}
                  isVerified={verifiedFiles.has(att.name + '-' + att.size)}
                />
              ))}
            </div>
          )}

          {/* Speech Recognition Error Alert */}
          {speechError && (
            <div className="mb-2.5 p-3 rounded-xl border border-rose-900/40 bg-rose-950/20 text-rose-400 text-xs flex items-center justify-between gap-2.5 font-mono">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
                <span>{speechError}</span>
              </div>
              <button 
                onClick={() => setSpeechError(null)} 
                className="text-rose-400 hover:text-rose-200 cursor-pointer p-0.5 rounded hover:bg-rose-950/40"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Real-time Voice Recognition Overlay Panel */}
          {isListening && (
            <div className="p-3.5 rounded-2xl border border-indigo-500/30 bg-indigo-950/25 shadow-lg shadow-indigo-950/20 flex flex-col gap-2.5 animate-in fade-in duration-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  {/* Glowing Soundwave Animation */}
                  <div className="flex items-end gap-[3px] h-3.5 shrink-0 px-1">
                    <span className="w-[3px] bg-indigo-400 rounded-full animate-pulse h-2.5" style={{ animationDelay: '0.1s', animationDuration: '0.8s' }} />
                    <span className="w-[3px] bg-indigo-400 rounded-full animate-pulse h-4" style={{ animationDelay: '0.3s', animationDuration: '0.6s' }} />
                    <span className="w-[3px] bg-indigo-400 rounded-full animate-pulse h-1.5" style={{ animationDelay: '0.5s', animationDuration: '1.1s' }} />
                    <span className="w-[3px] bg-indigo-400 rounded-full animate-pulse h-3.5" style={{ animationDelay: '0.2s', animationDuration: '0.7s' }} />
                    <span className="w-[3px] bg-indigo-400 rounded-full animate-pulse h-2" style={{ animationDelay: '0.4s', animationDuration: '0.9s' }} />
                  </div>
                  <span className="text-xs font-semibold text-indigo-400 flex items-center gap-1.5 select-none">
                    <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping shrink-0" />
                    {isRtl ? 'جاري الإملاء الصوتي المباشر...' : 'Live Voice Dictation Active...'}
                  </span>
                </div>
                <button
                  onClick={() => {
                    if (recognition) {
                      recognition.stop();
                    }
                  }}
                  className="text-[10px] px-2.5 py-1 rounded-lg bg-indigo-950/60 hover:bg-indigo-900/40 border border-indigo-900/40 text-indigo-300 font-semibold transition-all active:scale-95 cursor-pointer"
                >
                  {isRtl ? 'إيقاف وحفظ' : 'Stop & Save'}
                </button>
              </div>

              {/* Transcription Area */}
              <div className={`p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 min-h-[45px] text-xs leading-relaxed ${isRtl ? 'text-right' : 'text-left'}`}>
                {interimTranscript ? (
                  <span className="text-slate-200 italic font-medium">"{interimTranscript}"</span>
                ) : (
                  <span className="text-slate-500 italic select-none">
                    {isRtl ? 'تحدّث الآن، سيظهر نصّك هنا تلقائياً...' : 'Speak now, your speech will transcribe in real-time...'}
                  </span>
                )}
              </div>
            </div>
          )}

          {/* Prompt Entry Box */}
          <div className={`relative rounded-2xl border transition-all p-2 flex items-end gap-2.5 ${
            isListening 
              ? 'border-indigo-500/80 ring-1 ring-indigo-500/20 bg-indigo-950/10' 
              : 'border-slate-800/80 bg-slate-900/40 focus-within:border-indigo-500 focus-within:ring-1 focus-within:ring-indigo-500/10'
          }`}>
            
            {/* Attachment Button */}
            <button
              onClick={() => fileInputRef.current?.click()}
              className="p-2.5 rounded-xl text-slate-500 hover:text-slate-300 hover:bg-slate-900 transition-all cursor-pointer relative"
              title={t.uploadFile}
            >
              <Paperclip className="w-4 h-4" />
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                multiple
                className="hidden"
                accept="image/*,application/pdf,text/plain"
              />
            </button>

            {/* Voice Dictation (Web Speech API) */}
            <button
              type="button"
              onClick={toggleListening}
              className={`p-2.5 rounded-xl transition-all cursor-pointer relative ${
                isListening 
                  ? 'bg-rose-500/20 text-rose-400 hover:bg-rose-500/30 ring-1 ring-rose-500/50 animate-pulse' 
                  : 'text-slate-500 hover:text-slate-300 hover:bg-slate-900'
              }`}
              title={isRtl ? 'إملاء صوتي مباشر' : 'Live Voice Dictation'}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>

            {/* Input Text Box */}
            <textarea
              rows={1}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder={isListening ? (isRtl ? 'جاري الاستماع...' : 'Listening...') : t.chatPlaceholder}
              className="flex-1 text-sm bg-transparent border-0 outline-none text-slate-200 placeholder-slate-600 font-sans leading-relaxed max-h-[140px] resize-none py-2 px-1 text-right"
              style={{ height: 'auto' }}
            />

            {/* Send Button */}
            <button
              onClick={handleSend}
              disabled={!inputText.trim() && attachments.length === 0}
              className={`p-2.5 rounded-xl text-white font-medium flex items-center justify-center transition-all shadow-md cursor-pointer ${
                (inputText.trim() || attachments.length > 0)
                  ? 'bg-indigo-600 hover:bg-indigo-500 shadow-indigo-900/10'
                  : 'bg-slate-800 text-slate-600 cursor-not-allowed shadow-none'
              }`}
            >
              <Send className="w-4 h-4 rotate-180" />
            </button>
          </div>

          {/* Secure disclaimer */}
          <div className="flex items-center justify-between text-[10px] text-slate-600 select-none">
            <span className="flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-indigo-600 animate-pulse" />
              {isRtl ? 'مدعوم بنظام فحص الأخطاء والتحسين التلقائي' : 'Enhanced with self-improving error correction'}
            </span>
            <span>
              {isRtl ? 'الخصوصية والأمان مشفرة' : 'Privacy and intelligence guaranteed'}
            </span>
          </div>

        </div>
      </div>

      {/* File Preview & Verification Lightbox Modal */}
      <AnimatePresence>
        {previewFile && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Modal Header */}
              <div className="px-6 py-4 border-b border-slate-800/60 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-indigo-950/60 border border-indigo-900/30 text-indigo-400">
                    <Eye className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-100">
                      {isRtl ? 'بوابة فحص والتحقق من الملفات' : 'File Preview & Verification Hub'}
                    </h3>
                    <p className="text-[10px] text-slate-500 font-mono mt-0.5 max-w-[200px] md:max-w-md truncate">
                      {previewFile.name}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setPreviewFile(null)}
                  className="p-1.5 rounded-lg bg-slate-950 hover:bg-slate-850 text-slate-400 hover:text-white transition-all cursor-pointer border border-slate-800"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Modal Body / Viewer */}
              <div className="p-6 overflow-y-auto max-h-[60vh] space-y-4">
                {/* Visual Canvas Viewer depending on Mimetype */}
                <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-4 flex flex-col items-center justify-center min-h-[300px] relative">
                  {previewFile.type.startsWith('image/') ? (
                    <img
                      src={previewFile.data}
                      alt={previewFile.name}
                      className="max-h-[400px] object-contain rounded-xl select-none"
                      referrerPolicy="no-referrer"
                    />
                  ) : previewFile.type === 'application/pdf' || previewFile.name.toLowerCase().endsWith('.pdf') ? (
                    <div className="w-full h-full flex flex-col items-center space-y-3">
                      {/* Embed the PDF as an interactive iframe using the base64 data */}
                      <iframe
                        src={previewFile.data}
                        title={previewFile.name}
                        className="w-full h-[380px] rounded-xl border border-slate-800 bg-slate-900"
                      />
                      <a
                        href={previewFile.data}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 text-xs text-indigo-400 hover:text-indigo-300 font-medium py-1.5 px-3 rounded-lg bg-indigo-950/40 border border-indigo-900/30 transition-all cursor-pointer"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>{isRtl ? 'فتح المستند في نافذة كاملة' : 'Open PDF in Full Window'}</span>
                      </a>
                    </div>
                  ) : previewFile.type.startsWith('text/') || /\.(txt|md|py|js|ts|tsx|jsx|html|css|json|csv|log|yaml|yml|ini|conf|sql|sh|bash)$/i.test(previewFile.name) ? (
                    <div className="w-full text-right">
                      <p className="text-[10px] text-slate-500 font-mono mb-2">
                        {isRtl ? 'مستند نصي مشفر UTF-8' : 'Decoded UTF-8 Document'}
                      </p>
                      <div className="bg-slate-950 border border-slate-800/85 rounded-xl p-4 max-h-[350px] overflow-y-auto text-left font-mono text-xs text-emerald-400/90 whitespace-pre-wrap select-text leading-relaxed">
                        {getDecodedText(previewFile.data)}
                      </div>
                    </div>
                  ) : (
                    <div className="text-center space-y-3 p-8">
                      <div className="w-16 h-16 rounded-2xl bg-indigo-950/40 border border-indigo-900/30 flex items-center justify-center mx-auto text-indigo-400">
                        <FileText className="w-8 h-8 animate-pulse" />
                      </div>
                      <div>
                        <h4 className="text-sm font-semibold text-slate-200">
                          {isRtl ? 'الملف جاهز للمعالجة الذكية' : 'Binary File Ready for Computing'}
                        </h4>
                        <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 leading-relaxed">
                          {isRtl
                            ? 'تمت قراءة البيانات الثنائية بنجاح. هذا الملف جاهز للتمرير الآمن لنموذج الذكاء الاصطناعي للتحليل الشامل.'
                            : 'Binary payload parsed successfully. This file is safely structured and ready to be processed by the LLM.'}
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                {/* File Metadata Details Card */}
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4 bg-slate-950/30 border border-slate-800/55 rounded-2xl p-4 text-xs font-mono">
                  <div className="min-w-0">
                    <span className="text-slate-500 block mb-0.5">{isRtl ? 'اسم الملف:' : 'File Name:'}</span>
                    <span className="text-slate-300 font-semibold truncate block" title={previewFile.name}>{previewFile.name}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block mb-0.5">{isRtl ? 'حجم الملف:' : 'File Size:'}</span>
                    <span className="text-slate-300 font-semibold block">{(previewFile.size / 1024).toFixed(1)} KB</span>
                  </div>
                  <div className="col-span-2 md:col-span-1 min-w-0">
                    <span className="text-slate-500 block mb-0.5">{isRtl ? 'نوع البيانات:' : 'MIME Type:'}</span>
                    <span className="text-slate-300 font-semibold truncate block" title={previewFile.type}>{previewFile.type || 'unknown'}</span>
                  </div>
                </div>

                {/* Safety & Verification Statement */}
                <div className="p-4 rounded-2xl bg-emerald-950/15 border border-emerald-900/30 flex items-start gap-3">
                  <div className="p-1.5 rounded-lg bg-emerald-950/40 border border-emerald-900/20 text-emerald-400 shrink-0 mt-0.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-emerald-400">
                      {isRtl ? 'فحص الأمان والتحقق من التشفير' : 'Sandbox Security & Privacy Assurance'}
                    </h4>
                    <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">
                      {isRtl
                        ? 'تم تشفير هذا الملف وتجهيزه محلياً في متصفحك بشكل آمن. لن يتم استهلاكه إلا عند الضغط على إرسال، وتحت إشراف الخوارزميات الأمنية الذكية لـ Gemini.'
                        : 'This file is encrypted and packaged securely in your local browser sandbox. It is fully isolated and only transmitted when you trigger active query execution.'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Modal Footer actions */}
              <div className="px-6 py-4 border-t border-slate-800/60 bg-slate-950/40 flex items-center justify-between gap-3">
                <button
                  onClick={() => setPreviewFile(null)}
                  className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 text-xs font-semibold cursor-pointer transition-all active:scale-95"
                >
                  {isRtl ? 'إلغاء' : 'Cancel'}
                </button>

                <div className="flex items-center gap-2">
                  {verifiedFiles.has(previewFile.name + '-' + previewFile.size) ? (
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400 bg-emerald-950/40 border border-emerald-900/30 py-2 px-4 rounded-xl">
                      <ShieldCheck className="w-4 h-4 text-emerald-400 animate-pulse" />
                      <span>{isRtl ? 'تم التحقق والاعتماد' : 'Verified & Approved'}</span>
                    </div>
                  ) : (
                    <button
                      onClick={() => {
                        setVerifiedFiles((prev) => {
                          const next = new Set(prev);
                          next.add(previewFile.name + '-' + previewFile.size);
                          return next;
                        });
                        setPreviewFile(null);
                      }}
                      className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-md shadow-emerald-900/10 transition-all active:scale-95"
                    >
                      <ShieldCheck className="w-4 h-4" />
                      <span>{isRtl ? 'اعتماد وصحة الملف للتحليل' : 'Approve & Mark as Verified'}</span>
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
