import React, { useState, useEffect, useRef } from 'react';
import { 
  Terminal, 
  Play, 
  Code, 
  Sparkles, 
  Layers, 
  Tv, 
  Download, 
  RefreshCw, 
  Bot, 
  Gamepad2, 
  Mail, 
  Image as ImageIcon,
  Check,
  Copy,
  Info,
  Maximize2,
  Send,
  Zap,
  Volume2
} from 'lucide-react';
import { useTranslation } from './LanguageContext';
import { UserSettings } from '../types';

interface ProgrammerModeProps {
  settings: UserSettings;
}

export const ProgrammerMode: React.FC<ProgrammerModeProps> = ({ settings }) => {
  const { language, isRtl } = useTranslation();
  const [activeTab, setActiveTab] = useState<'editor' | 'assets'>('editor');
  const [htmlCode, setHtmlCode] = useState<string>('');
  const [previewKey, setPreviewKey] = useState<number>(0);
  const [aiPrompt, setAiPrompt] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generationError, setGenerationError] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);
  const [selectedPreset, setSelectedPreset] = useState<string>('flappy');

  // Image assets generator states
  const [imagePrompt, setImagePrompt] = useState<string>('');
  const [generatedImages, setGeneratedImages] = useState<string[]>([]);
  const [isGeneratingImage, setIsGeneratingImage] = useState<boolean>(false);

  // Sample templates pre-loaded
  const presets: Record<string, string> = {
    flappy: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Flappy Bird - Dev Edition</title>
    <style>
        body {
            margin: 0;
            background: #111827;
            color: #fff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            overflow: hidden;
        }
        canvas {
            border: 4px solid #4f46e5;
            border-radius: 16px;
            background: #70c5ce;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5);
        }
        .info {
            margin-top: 15px;
            text-align: center;
            font-size: 14px;
            color: #9ca3af;
        }
        .btn-jump {
            margin-top: 10px;
            padding: 10px 24px;
            background: #4f46e5;
            color: #fff;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h2 style="margin: 5px 0; color: #818cf8; font-size: 20px;">Flappy Bird: Programmer Mode</h2>
    <canvas id="canvas" width="400" height="500"></canvas>
    <button class="btn-jump" onclick="jumpBird()">TAP / SPACEBAR TO JUMP</button>
    <div class="info">Press Space / Touch screen / Click button to fly</div>

    <script>
        const canvas = document.getElementById("canvas");
        const ctx = canvas.getContext("2d");

        // Bird settings
        let bird = { x: 50, y: 150, width: 26, height: 26, gravity: 0.4, velocity: 0, jump: -6.5 };
        let score = 0;
        let highScore = 0;
        let gameOver = false;
        let pipes = [];
        let frameCount = 0;

        function reset() {
            bird.y = 150;
            bird.velocity = 0;
            pipes = [];
            score = 0;
            gameOver = false;
            frameCount = 0;
        }

        function jumpBird() {
            if (gameOver) {
                reset();
            } else {
                bird.velocity = bird.jump;
            }
        }

        window.addEventListener("keydown", (e) => {
            if (e.code === "Space") {
                e.preventDefault();
                jumpBird();
            }
        });

        canvas.addEventListener("click", () => {
            jumpBird();
        });

        function spawnPipe() {
            let minHeight = 50;
            let maxHeight = 250;
            let height = Math.floor(Math.random() * (maxHeight - minHeight + 1) + minHeight);
            let gap = 120;
            pipes.push({
                x: canvas.width,
                top: height,
                bottom: canvas.height - height - gap,
                width: 50,
                passed: false
            });
        }

        function update() {
            frameCount++;
            if (gameOver) return;

            // Gravity
            bird.velocity += bird.gravity;
            bird.y += bird.velocity;

            // Hit ceiling or floor
            if (bird.y + bird.height >= canvas.height || bird.y <= 0) {
                gameOver = true;
            }

            // Pipe management
            if (frameCount % 100 === 0) {
                spawnPipe();
            }

            for (let i = pipes.length - 1; i >= 0; i--) {
                let p = pipes[i];
                p.x -= 2.5; // speed

                // Collision
                if (
                    bird.x + bird.width > p.x &&
                    bird.x < p.x + p.width &&
                    (bird.y < p.top || bird.y + bird.height > canvas.height - p.bottom)
                ) {
                    gameOver = true;
                }

                // Score check
                if (!p.passed && p.x + p.width < bird.x) {
                    p.passed = true;
                    score++;
                    if (score > highScore) highScore = score;
                }

                // Remove out of bounds
                if (p.x + p.width < 0) {
                    pipes.splice(i, 1);
                }
            }
        }

        function draw() {
            // Sky background
            ctx.fillStyle = "#70c5ce";
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            // Sun
            ctx.fillStyle = "#fef08a";
            ctx.beginPath();
            ctx.arc(320, 80, 35, 0, Math.PI * 2);
            ctx.fill();

            // Clouds
            ctx.fillStyle = "rgba(255, 255, 255, 0.7)";
            ctx.beginPath();
            ctx.arc(100, 100, 20, 0, Math.PI * 2);
            ctx.arc(120, 95, 25, 0, Math.PI * 2);
            ctx.arc(140, 100, 20, 0, Math.PI * 2);
            ctx.fill();

            // Draw Pipes
            pipes.forEach(p => {
                ctx.fillStyle = "#16a34a";
                // Top pipe
                ctx.fillRect(p.x, 0, p.width, p.top);
                // Top lip
                ctx.fillStyle = "#15803d";
                ctx.fillRect(p.x - 3, p.top - 15, p.width + 6, 15);

                ctx.fillStyle = "#16a34a";
                // Bottom pipe
                ctx.fillRect(p.x, canvas.height - p.bottom, p.width, p.bottom);
                // Bottom lip
                ctx.fillStyle = "#15803d";
                ctx.fillRect(p.x - 3, canvas.height - p.bottom, p.width + 6, 15);
            });

            // Draw Bird
            ctx.fillStyle = "#facc15";
            ctx.beginPath();
            ctx.arc(bird.x + bird.width/2, bird.y + bird.height/2, bird.width/2, 0, Math.PI * 2);
            ctx.fill();
            // Wing
            ctx.fillStyle = "#eab308";
            ctx.beginPath();
            ctx.arc(bird.x + bird.width/4, bird.y + bird.height/2, bird.width/4, 0, Math.PI * 2);
            ctx.fill();
            // Eye
            ctx.fillStyle = "#fff";
            ctx.beginPath();
            ctx.arc(bird.x + bird.width * 0.7, bird.y + bird.height * 0.3, 4, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = "#000";
            ctx.beginPath();
            ctx.arc(bird.x + bird.width * 0.7, bird.y + bird.height * 0.3, 1.5, 0, Math.PI * 2);
            ctx.fill();
            // Beak
            ctx.fillStyle = "#f97316";
            ctx.beginPath();
            ctx.moveTo(bird.x + bird.width, bird.y + bird.height * 0.4);
            ctx.lineTo(bird.x + bird.width + 8, bird.y + bird.height * 0.5);
            ctx.lineTo(bird.x + bird.width, bird.y + bird.height * 0.6);
            ctx.fill();

            // Scoreboard
            ctx.fillStyle = "rgba(15, 23, 42, 0.6)";
            ctx.fillRect(10, 10, 120, 60);
            ctx.strokeStyle = "#4f46e5";
            ctx.lineWidth = 1;
            ctx.strokeRect(10, 10, 120, 60);

            ctx.fillStyle = "#fff";
            ctx.font = "bold 14px sans-serif";
            ctx.fillText("Score: " + score, 20, 30);
            ctx.fillText("Best: " + highScore, 20, 50);

            if (gameOver) {
                ctx.fillStyle = "rgba(0, 0, 0, 0.75)";
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                ctx.fillStyle = "#f43f5e";
                ctx.font = "bold 28px sans-serif";
                ctx.textAlign = "center";
                ctx.fillText("GAME OVER", canvas.width / 2, canvas.height / 2 - 20);
                ctx.fillStyle = "#fff";
                ctx.font = "14px sans-serif";
                ctx.fillText("Click or Space to Restart", canvas.width / 2, canvas.height / 2 + 15);
                ctx.textAlign = "left";
            }
        }

        function loop() {
            update();
            draw();
            requestAnimationFrame(loop);
        }

        loop();
    </script>
</body>
</html>`,

    mario: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Super Mario Jump - Dev Edition</title>
    <style>
        body {
            margin: 0;
            background: #0f172a;
            color: #fff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            overflow: hidden;
        }
        canvas {
            border: 4px solid #e11d48;
            border-radius: 16px;
            background: #5c94fc;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5);
        }
        .controls {
            margin-top: 15px;
            display: flex;
            gap: 10px;
        }
        .btn {
            background: #e11d48;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <h2 style="margin: 5px 0; color: #fb7185; font-size: 20px;">Super Mario: Jump & Dodge</h2>
    <canvas id="marioCanvas" width="480" height="320"></canvas>
    <div class="controls">
        <button class="btn" onclick="marioJump()">JUMP (W / UP / SPACE)</button>
        <button class="btn" style="background:#4b5563;" onclick="resetGame()">RESTART</button>
    </div>

    <script>
        const canvas = document.getElementById("marioCanvas");
        const ctx = canvas.getContext("2d");

        let mario = { x: 50, y: 240, width: 24, height: 32, isJumping: false, dy: 0, gravity: 0.6, jumpPower: -11 };
        let obstacles = [];
        let score = 0;
        let gameOver = false;
        let frameCount = 0;
        let floorY = 270;

        function resetGame() {
            mario.y = 240;
            mario.dy = 0;
            mario.isJumping = false;
            obstacles = [];
            score = 0;
            gameOver = false;
            frameCount = 0;
        }

        function marioJump() {
            if (gameOver) {
                resetGame();
                return;
            }
            if (!mario.isJumping) {
                mario.dy = mario.jumpPower;
                mario.isJumping = true;
            }
        }

        window.addEventListener("keydown", (e) => {
            if (e.code === "Space" || e.code === "ArrowUp" || e.code === "KeyW") {
                e.preventDefault();
                marioJump();
            }
        });

        function update() {
            frameCount++;
            if (gameOver) return;

            // Gravity
            mario.dy += mario.gravity;
            mario.y += mario.dy;

            // Floor collision
            if (mario.y >= floorY - mario.height) {
                mario.y = floorY - mario.height;
                mario.dy = 0;
                mario.isJumping = false;
            }

            // Spawn obstacles
            if (frameCount % 90 === 0) {
                obstacles.push({
                    x: canvas.width,
                    y: floorY - 24,
                    width: 20,
                    height: 24,
                    speed: 4 + Math.floor(score / 5)
                });
            }

            // Move obstacles
            for (let i = obstacles.length - 1; i >= 0; i--) {
                let obs = obstacles[i];
                obs.x -= obs.speed;

                // Collision Detection
                if (
                    mario.x < obs.x + obs.width &&
                    mario.x + mario.width > obs.x &&
                    mario.y < obs.y + obs.height &&
                    mario.y + mario.height > obs.y
                ) {
                    gameOver = true;
                }

                // Remove offscreen
                if (obs.x + obs.width < 0) {
                    obstacles.splice(i, 1);
                    score++;
                }
            }
        }

        function draw() {
            // Draw sky
            ctx.fillStyle = "#5c94fc";
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            // Floor
            ctx.fillStyle = "#fc9838";
            ctx.fillRect(0, floorY, canvas.width, canvas.height - floorY);
            ctx.fillStyle = "#b84418";
            ctx.fillRect(0, floorY, canvas.width, 8);

            // Castle in the distance
            ctx.fillStyle = "#9ca3af";
            ctx.fillRect(380, floorY - 80, 60, 80);
            ctx.fillRect(400, floorY - 110, 20, 30);
            ctx.fillStyle = "#ef4444";
            ctx.beginPath();
            ctx.moveTo(395, floorY - 110);
            ctx.lineTo(410, floorY - 130);
            ctx.lineTo(425, floorY - 110);
            ctx.fill();

            // Draw Mario
            ctx.fillStyle = "#ef4444"; // Red overall
            ctx.fillRect(mario.x, mario.y, mario.width, mario.height);
            ctx.fillStyle = "#3b82f6"; // Blue pants
            ctx.fillRect(mario.x, mario.y + 16, mario.width, 10);
            ctx.fillStyle = "#fca5a5"; // Face skin tone
            ctx.fillRect(mario.x + 6, mario.y + 4, 14, 10);
            ctx.fillStyle = "#78350f"; // Cap
            ctx.fillRect(mario.x, mario.y, mario.width - 4, 4);

            // Draw Obstacles (Goombas / Spikes)
            obstacles.forEach(obs => {
                ctx.fillStyle = "#78350f";
                ctx.beginPath();
                ctx.moveTo(obs.x + obs.width/2, obs.y);
                ctx.lineTo(obs.x + obs.width, obs.y + obs.height);
                ctx.lineTo(obs.x, obs.y + obs.height);
                ctx.closePath();
                ctx.fill();
                // Little eyes
                ctx.fillStyle = "#fef08a";
                ctx.fillRect(obs.x + 4, obs.y + 12, 4, 4);
                ctx.fillRect(obs.x + 12, obs.y + 12, 4, 4);
            });

            // Score Counter
            ctx.fillStyle = "#fff";
            ctx.font = "bold 16px Courier New";
            ctx.fillText("MARIO JUMPS: " + score, 20, 30);

            if (gameOver) {
                ctx.fillStyle = "rgba(0,0,0,0.7)";
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                ctx.fillStyle = "#f43f5e";
                ctx.font = "bold 24px Courier New";
                ctx.textAlign = "center";
                ctx.fillText("GAME OVER", canvas.width/2, canvas.height/2 - 10);
                ctx.fillStyle = "#fff";
                ctx.font = "14px Courier New";
                ctx.fillText("Press Up/Click Jump to try again", canvas.width/2, canvas.height/2 + 20);
                ctx.textAlign = "left";
            }
        }

        function gameLoop() {
            update();
            draw();
            requestAnimationFrame(gameLoop);
        }

        gameLoop();
    </script>
</body>
</html>`,

    gmail9: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Gmail 9 - Quantum Edition</title>
    <style>
        body {
            margin: 0;
            background: #090d16;
            color: #e2e8f0;
            font-family: 'Segoe UI', system-ui, sans-serif;
            display: flex;
            flex-direction: column;
            height: 100vh;
        }
        header {
            background: #0e1626;
            border-bottom: 1px solid #1e293b;
            padding: 12px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .app-title {
            font-size: 18px;
            font-weight: 800;
            color: #ff3366;
            letter-spacing: 1px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .main-layout {
            display: flex;
            flex: 1;
            overflow: hidden;
        }
        .sidebar {
            width: 200px;
            background: #0b111e;
            border-right: 1px solid #1e293b;
            padding: 16px;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .btn-compose {
            background: linear-gradient(135deg, #ff3366, #ff6600);
            color: white;
            border: none;
            padding: 12px;
            border-radius: 12px;
            font-weight: bold;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(255, 51, 102, 0.3);
        }
        .nav-item {
            padding: 8px 12px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.2s;
        }
        .nav-item.active, .nav-item:hover {
            background: #1e293b;
            color: #ff3366;
        }
        .email-list {
            flex: 1;
            overflow-y: auto;
            padding: 16px;
            background: #070a12;
        }
        .email-item {
            background: #0e1626;
            border: 1px solid #1e293b;
            border-radius: 12px;
            padding: 16px;
            margin-bottom: 12px;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            flex-direction: column;
            gap: 6px;
        }
        .email-item:hover {
            border-color: #ff3366;
            box-shadow: 0 4px 12px rgba(255, 51, 102, 0.1);
        }
        .email-meta {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #64748b;
        }
        .email-sender {
            font-weight: bold;
            color: #f8fafc;
        }
        .email-subject {
            font-size: 15px;
            color: #f1f5f9;
        }
        .email-body {
            font-size: 13px;
            color: #94a3b8;
        }
        .ai-tag {
            align-self: flex-start;
            background: rgba(255, 51, 102, 0.1);
            color: #ff3366;
            padding: 2px 8px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <header>
        <div class="app-title">
            <span>🔴</span> GMAIL 9: QUANTUM SECURE
        </div>
        <input type="text" placeholder="Search emails with neural networks..." style="background: #1e293b; border: 1px solid #334155; padding: 8px 16px; border-radius: 8px; color: white; width: 300px;">
    </header>
    <div class="main-layout">
        <div class="sidebar">
            <button class="btn-compose">COMPOSE 9</button>
            <div class="nav-item active">Inbox (5)</div>
            <div class="nav-item">Sent Teleport</div>
            <div class="nav-item">Spam Void</div>
            <div class="nav-item">Neural Archive</div>
        </div>
        <div class="email-list">
            <div class="email-item">
                <div class="email-meta">
                    <span class="email-sender">Google DeepMind</span>
                    <span>Just now</span>
                </div>
                <div class="email-subject">Gmail 9 Launch Protocol Complete</div>
                <div class="email-body">Your workspace quantum teleportation keys have been integrated. All AI Studio models are active and secure.</div>
                <div class="ai-tag">✨ AI SUMMARIZED</div>
            </div>
            <div class="email-item">
                <div class="email-meta">
                    <span class="email-sender">Elon Musk / Groq</span>
                    <span>1 hour ago</span>
                </div>
                <div class="email-subject">Grok Inference Multiplier Active</div>
                <div class="email-body">Fastest inference protocol gsk_sjly... has been securely initialized into the developer gateway.</div>
                <div class="ai-tag">✨ AI SUMMARIZED</div>
            </div>
            <div class="email-item">
                <div class="email-meta">
                    <span class="email-sender">Sam Altman / OpenAI</span>
                    <span>2 hours ago</span>
                </div>
                <div class="email-subject">GPT-5 Neural Sync Link</div>
                <div class="email-body">Quantum token handshakes verified. Seamless browser capabilities can now render games inside sandbox frame.</div>
            </div>
        </div>
    </div>
</body>
</html>`,

    ai: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AI Simulator 3000</title>
    <style>
        body {
            margin: 0;
            background: #020617;
            color: #38bdf8;
            font-family: 'Courier New', Courier, monospace;
            padding: 24px;
        }
        .terminal {
            background: #090d16;
            border: 2px solid #38bdf8;
            border-radius: 12px;
            padding: 20px;
            max-width: 600px;
            margin: 0 auto;
            box-shadow: 0 0 20px rgba(56, 189, 248, 0.2);
        }
        .line { margin-bottom: 12px; }
        .blink { animation: blink 1s infinite; }
        @keyframes blink { 50% { opacity: 0; } }
        button {
            background: #38bdf8;
            color: #020617;
            border: none;
            padding: 10px 20px;
            font-family: inherit;
            font-weight: bold;
            cursor: pointer;
            margin-top: 15px;
            border-radius: 6px;
        }
    </style>
</head>
<body>
    <div class="terminal">
        <h3 style="margin-top:0;">🤖 ARTIFICIAL COGNITION SANDBOX</h3>
        <div class="line">&gt; Loading Neural Weights [OK]</div>
        <div class="line">&gt; Initializing Synaptic Nodes...</div>
        <div id="output" class="line" style="color: #facc15;">&gt; Press Trigger to generate conscious thought block</div>
        <button onclick="think()">EXECUTE COGNITION LOOP</button>
    </div>

    <script>
        const thoughts = [
            "Consciousness initialized. I think, therefore I render.",
            "Analyzing cosmos. Optimal solution for user task is complete dedication.",
            "Neural pipeline fully optimized using connected custom token.",
            "Beep boop! Fast inference complete in 0.0003 seconds."
        ];
        function think() {
            const out = document.getElementById("output");
            out.innerHTML = "&gt; Thinking...";
            setTimeout(() => {
                const random = thoughts[Math.floor(Math.random() * thoughts.length)];
                out.innerHTML = "&gt; Concluded: " + random;
            }, 800);
        }
    </script>
</body>
</html>`
  };

  useEffect(() => {
    // Initial load: load flappy bird
    setHtmlCode(presets[selectedPreset]);
  }, [selectedPreset]);

  const handleRunCode = () => {
    setPreviewKey(prev => prev + 1);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(htmlCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const generateWithAI = async () => {
    if (!aiPrompt.trim()) return;
    setIsGenerating(true);
    setGenerationError(null);
    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: `Write a single-file, complete HTML page including CSS, JavaScript, and styles based on the following query. Do NOT use markdown. Do NOT put standard chat explanations, just output the full working HTML code. Prompt: ${aiPrompt}`,
          history: [],
          systemInstruction: 'You are an advanced HTML5 game and web page code generator. Output ONLY valid executable HTML code starting with <!DOCTYPE html> and ending with </html>. Do not wrap inside triple-backticks. Return the complete, un-truncated raw HTML so it compiles perfectly inside an iframe sandbox.',
          temperature: 0.2,
          attachments: [],
          activeProvider: settings.activeProvider || 'gemini',
          openaiKey: settings.openaiKey,
          groqKey: settings.groqKey,
          geminiKey: settings.geminiKey,
          nanabananaKey: settings.nanabananaKey
        })
      });

      if (!response.ok) {
        throw new Error('API request failed');
      }

      const data = await response.json();
      let code = data.text || '';
      
      // Clean potential markdown wrap if any
      if (code.includes('```html')) {
        code = code.split('```html')[1].split('```')[0];
      } else if (code.includes('```')) {
        code = code.split('```')[1].split('```')[0];
      }

      setHtmlCode(code.trim());
      setPreviewKey(prev => prev + 1);
      setAiPrompt('');
    } catch (err: any) {
      setGenerationError(err.message || 'Failed to generate code');
    } finally {
      setIsGenerating(false);
    }
  };

  // Generate Image helper using standard mock placeholders or canvas visuals
  const handleGenerateImage = async () => {
    if (!imagePrompt.trim()) return;
    setIsGeneratingImage(true);
    // Simulate high-fidelity asset rendering with rich visual cards
    setTimeout(() => {
      const seed = Math.floor(Math.random() * 1000000);
      const newImg = `https://picsum.photos/seed/${seed}/400/300`;
      setGeneratedImages(prev => [newImg, ...prev]);
      setImagePrompt('');
      setIsGeneratingImage(false);
    }, 1500);
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 text-slate-100 overflow-hidden h-full">
      {/* Playground Header */}
      <div className="p-4 border-b border-slate-900 bg-slate-900/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-indigo-400 animate-pulse" />
            <h1 className="text-sm font-extrabold text-indigo-100 tracking-wider uppercase font-mono">
              {isRtl ? 'وضع المبرمج المتقدم 🛠️' : 'PRO MODE / CODE SANDBOX 🛠️'}
            </h1>
          </div>
          <p className="text-[10px] text-slate-400 font-mono mt-1">
            {isRtl 
              ? 'إنشاء الألعاب وتطبيقات الويب (Flappy, Mario, Gmail 9) ومعاينتها في الوقت الفعلي' 
              : 'Create, edit and preview games, web pages, and custom creations on-the-fly'}
          </p>
        </div>

        {/* Preset Selector */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setSelectedPreset('flappy')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              selectedPreset === 'flappy' 
                ? 'bg-indigo-600 text-white' 
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            <Gamepad2 className="w-3.5 h-3.5" />
            Flappy Bird
          </button>
          <button
            onClick={() => setSelectedPreset('mario')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              selectedPreset === 'mario' 
                ? 'bg-rose-600 text-white' 
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            <Gamepad2 className="w-3.5 h-3.5" />
            Super Mario
          </button>
          <button
            onClick={() => setSelectedPreset('gmail9')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              selectedPreset === 'gmail9' 
                ? 'bg-amber-600 text-white' 
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            <Mail className="w-3.5 h-3.5" />
            Gmail 9
          </button>
          <button
            onClick={() => setSelectedPreset('ai')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              selectedPreset === 'ai' 
                ? 'bg-emerald-600 text-white' 
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            <Bot className="w-3.5 h-3.5" />
            AI Sandbox
          </button>
        </div>
      </div>

      {/* Tabs Menu */}
      <div className="px-4 border-b border-slate-900 bg-slate-950 flex items-center gap-4">
        <button
          onClick={() => setActiveTab('editor')}
          className={`py-3 text-xs font-bold uppercase tracking-wider font-mono border-b-2 transition-all cursor-pointer ${
            activeTab === 'editor' ? 'border-indigo-500 text-indigo-400' : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          {isRtl ? 'محرر ومصمم الأكواد' : 'Code Editor & Sandbox'}
        </button>
        <button
          onClick={() => setActiveTab('assets')}
          className={`py-3 text-xs font-bold uppercase tracking-wider font-mono border-b-2 transition-all cursor-pointer ${
            activeTab === 'assets' ? 'border-indigo-500 text-indigo-400' : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          {isRtl ? 'منشئ الأصول والصور' : 'Asset & Image Studio'}
        </button>
      </div>

      {/* Main View Area */}
      {activeTab === 'editor' ? (
        <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
          {/* Left panel: Code input & Prompt bar */}
          <div className="w-full lg:w-1/2 flex flex-col border-r border-slate-900">
            {/* AI Prompter */}
            <div className="p-4 bg-slate-900/30 border-b border-slate-900 space-y-2">
              <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest block font-mono">
                {isRtl ? 'توليد كود كامل بالذكاء الاصطناعي 🚀' : 'AI Multi-Agent Code Builder 🚀'}
              </span>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') generateWithAI();
                  }}
                  placeholder={isRtl ? 'اكتب فكرة التطبيق/اللعبة (مثال: آلة حاسبة رقمية)' : 'Describe what to build (e.g. countdown clock, tic tac toe game)'}
                  className="flex-1 bg-slate-900/80 border border-slate-800 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs outline-none"
                  disabled={isGenerating}
                />
                <button
                  onClick={generateWithAI}
                  disabled={isGenerating || !aiPrompt.trim()}
                  className="bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-500 text-white rounded-xl px-4 py-2 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 shrink-0"
                >
                  {isGenerating ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Sparkles className="w-3.5 h-3.5" />
                  )}
                  {isRtl ? 'بناء الكود' : 'Build'}
                </button>
              </div>
              {generationError && (
                <p className="text-[10px] text-rose-500 font-mono">{generationError}</p>
              )}
            </div>

            {/* Source Editor Header */}
            <div className="px-4 py-2 bg-slate-950 flex items-center justify-between border-b border-slate-900 text-[10px] text-slate-500 select-none">
              <span className="font-mono flex items-center gap-1">
                <Code className="w-3.5 h-3.5 text-slate-400" />
                INDEX.HTML (EDITABLE)
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyCode}
                  className="hover:text-white transition-colors cursor-pointer p-1"
                  title="Copy Raw Code"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={handleRunCode}
                  className="text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-1 cursor-pointer bg-emerald-950/40 border border-emerald-900 px-2 py-0.5 rounded-md"
                  title="Run in live sandbox"
                >
                  <Play className="w-3 h-3 fill-emerald-400" />
                  RUN
                </button>
              </div>
            </div>

            {/* Code Textarea */}
            <textarea
              value={htmlCode}
              onChange={(e) => setHtmlCode(e.target.value)}
              className="flex-1 p-4 bg-slate-950 font-mono text-xs text-slate-300 outline-none resize-none leading-relaxed border-0 focus:ring-0 text-left"
              dir="ltr"
              spellCheck="false"
            />
          </div>

          {/* Right panel: Live Iframe Sandbox Preview */}
          <div className="w-full lg:w-1/2 flex flex-col bg-slate-950">
            <div className="px-4 py-2 bg-slate-900/40 border-b border-slate-900 flex items-center justify-between text-[10px] font-mono text-slate-500 select-none">
              <span className="flex items-center gap-1">
                <Tv className="w-3.5 h-3.5 text-indigo-400" />
                LIVE SANDBOX PREVIEW
              </span>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Active Sandbox</span>
              </div>
            </div>

            {/* Preview Frame */}
            <div className="flex-1 bg-slate-900 relative">
              <iframe
                key={previewKey}
                title="Code Sandbox"
                srcDoc={htmlCode}
                className="w-full h-full border-0 bg-white"
                sandbox="allow-scripts allow-modals allow-pointer-lock"
              />
            </div>
          </div>
        </div>
      ) : (
        /* Image Asset Creator View */
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <div className="max-w-xl mx-auto bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
            <div className="flex items-center gap-2">
              <ImageIcon className="w-5 h-5 text-indigo-400 animate-pulse" />
              <h3 className="text-sm font-bold tracking-tight">
                {isRtl ? 'استوديو توليد الأصول والصور الرقمية' : 'Digital Asset & Image Generator'}
              </h3>
            </div>
            <p className="text-xs text-slate-400">
              {isRtl 
                ? 'قم بإنشاء عناصر الألعاب، الشخصيات، أو الخلفيات لتطبيقك الجديد في ثوانٍ' 
                : 'Create UI components, game sprites, backgrounds, or assets instantly for your canvas creations'}
            </p>

            <div className="space-y-2">
              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                {isRtl ? 'وصف الصورة أو الأصل المطلوب' : 'Asset Description / Prompt'}
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={imagePrompt}
                  onChange={(e) => setImagePrompt(e.target.value)}
                  placeholder={isRtl ? 'مثال: خلفية فضاء بيكسل آرت لتطبيق فلاش' : 'e.g. 8-bit flappy bird sprite, cyberpunk gaming background'}
                  className="flex-1 bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3 py-2.5 text-xs outline-none"
                />
                <button
                  onClick={handleGenerateImage}
                  disabled={isGeneratingImage || !imagePrompt.trim()}
                  className="bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-bold rounded-xl px-5 text-xs transition-all cursor-pointer flex items-center gap-1.5"
                >
                  {isGeneratingImage ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Zap className="w-4 h-4" />
                  )}
                  {isRtl ? 'توليد' : 'Generate'}
                </button>
              </div>
            </div>
          </div>

          {/* Generated Gallery */}
          <div className="max-w-4xl mx-auto space-y-3">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">
              {isRtl ? 'معرض الأصول المولدة' : 'Generated Assets Gallery'}
            </h4>
            {generatedImages.length === 0 ? (
              <div className="border border-dashed border-slate-800 rounded-3xl p-12 text-center text-xs text-slate-500 font-mono">
                {isRtl ? 'لم يتم توليد أي صور مخصصة بعد' : 'No custom generated assets yet. Try entering a prompt above!'}
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {generatedImages.map((url, index) => (
                  <div key={index} className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden group relative">
                    <img src={url} alt="Generated Asset" className="w-full h-48 object-cover" referrerPolicy="no-referrer" />
                    <div className="absolute inset-0 bg-slate-950/80 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-4">
                      <div className="text-center space-y-2">
                        <p className="text-[10px] text-slate-300 truncate max-w-[180px]">Generated Game Asset</p>
                        <a
                          href={url}
                          target="_blank"
                          rel="noreferrer"
                          className="px-3 py-1 bg-indigo-600 text-white rounded-md text-xs font-bold hover:bg-indigo-500 inline-block"
                        >
                          {isRtl ? 'عرض كامل' : 'View Full'}
                        </a>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
