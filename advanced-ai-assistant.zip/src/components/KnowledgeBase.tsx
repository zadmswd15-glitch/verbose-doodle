import React, { useState } from 'react';
import { X, Brain, Plus, Trash2, Shield, AlertCircle, Bookmark } from 'lucide-react';
import { useTranslation } from './LanguageContext';
import { LearnedKnowledge } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface KnowledgeBaseProps {
  isOpen: boolean;
  onClose: () => void;
  knowledge: LearnedKnowledge[];
  onAddFact: (fact: string, category: string) => void;
  onDeleteFact: (id: string) => void;
}

export const KnowledgeBase: React.FC<KnowledgeBaseProps> = ({
  isOpen,
  onClose,
  knowledge,
  onAddFact,
  onDeleteFact
}) => {
  const { t, isRtl } = useTranslation();
  const [newFact, setNewFact] = useState('');
  const [category, setCategory] = useState('preference');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFact.trim()) return;
    onAddFact(newFact.trim(), category);
    setNewFact('');
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm"
          />

          {/* Modal content */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl shadow-indigo-950/20 overflow-hidden text-slate-100 flex flex-col max-h-[85vh]"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-900/50 select-none">
              <div className="flex items-center gap-2.5">
                <Brain className="w-5 h-5 text-indigo-400" />
                <h2 className="text-base font-bold tracking-tight">{t.learnedMemory}</h2>
              </div>
              <button
                onClick={onClose}
                className="text-slate-400 hover:text-white transition-colors p-1 rounded-lg hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Informative Header */}
              <div className="space-y-2">
                <p className="text-xs text-slate-400 leading-relaxed">
                  {t.memoryDesc}
                </p>
              </div>

              {/* Add Fact Form */}
              <form onSubmit={handleSubmit} className="p-4 rounded-xl border border-slate-800/80 bg-slate-950/20 space-y-3">
                <label className="text-xs font-bold text-slate-300 block select-none">
                  {t.addCustomFact}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newFact}
                    onChange={(e) => setNewFact(e.target.value)}
                    placeholder={t.factPlaceholder}
                    className="flex-1 text-xs bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500 font-sans"
                  />
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="text-xs bg-slate-950 border border-slate-800 rounded-lg px-2 py-2 text-slate-300 focus:outline-none font-sans"
                  >
                    <option value="preference">{isRtl ? 'تفضيل' : 'Preference'}</option>
                    <option value="tech">{isRtl ? 'برمجة/تقنية' : 'Tech/Dev'}</option>
                    <option value="bio">{isRtl ? 'حياة/عمل' : 'Bio/Work'}</option>
                    <option value="location">{isRtl ? 'موقع جغرافي' : 'Location'}</option>
                  </select>
                  <button
                    type="submit"
                    className="p-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white hover:text-white transition-all cursor-pointer shadow-md shadow-indigo-950/20"
                    title={t.addBtn}
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </form>

              {/* Facts List */}
              <div className="space-y-2">
                {knowledge.length === 0 ? (
                  <div className="p-10 border border-dashed border-slate-800 rounded-xl text-center text-xs text-slate-500 italic space-y-2">
                    <AlertCircle className="w-6 h-6 text-slate-600 mx-auto" />
                    <p>{t.noMemory}</p>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-[250px] overflow-y-auto">
                    {knowledge.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between p-3 rounded-xl border border-slate-800 bg-slate-950/40 hover:bg-slate-950/60 transition-all group font-sans"
                      >
                        <div className="flex items-center gap-3 pr-2 truncate text-right">
                          <Bookmark className="w-4 h-4 text-indigo-400 shrink-0" />
                          <div className="truncate">
                            <p className="text-xs text-slate-200 truncate font-medium text-right">
                              {item.fact}
                            </p>
                            <span className="text-[9px] text-slate-500 mt-1 block font-mono text-right">
                              {t.memoryCategory}: <span className="text-slate-400">{item.category}</span> • {item.autoDetected ? t.auto : t.manual}
                            </span>
                          </div>
                        </div>

                        <button
                          onClick={() => onDeleteFact(item.id)}
                          className="text-slate-600 hover:text-rose-400 p-1 rounded hover:bg-slate-800/40 opacity-0 group-hover:opacity-100 transition-all duration-150 cursor-pointer"
                          title={t.delete}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between p-5 border-t border-slate-800 bg-slate-950/40 select-none">
              <span className="text-[10px] text-slate-500 font-mono flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-emerald-500" />
                {isRtl ? 'قاعدة البيانات الذاتية مؤمنة' : 'Autonomous Database Vault Engaged'}
              </span>
              <button
                onClick={onClose}
                className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors cursor-pointer"
              >
                {t.close}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
