import React, { useState } from 'react';
import { X, Settings, RotateCcw, ShieldAlert, Sparkles, Sliders } from 'lucide-react';
import { useTranslation } from './LanguageContext';
import { UserSettings } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: UserSettings;
  onSaveSettings: (settings: UserSettings) => void;
  onClearAll: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  onClearAll
}) => {
  const { t, isRtl } = useTranslation();
  const [localSettings, setLocalSettings] = useState<UserSettings>({ ...settings });

  const handleSave = () => {
    onSaveSettings(localSettings);
    onClose();
  };

  const handleReset = () => {
    setLocalSettings({
      theme: 'dark',
      language: 'ar',
      temperature: 0.7,
      systemInstruction: '',
      memoryEnabled: true
    });
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm"
          />

          {/* Modal Box */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl shadow-indigo-950/20 overflow-hidden text-slate-100 flex flex-col max-h-[90vh]"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-900/50">
              <div className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-indigo-500 animate-spin" style={{ animationDuration: '6s' }} />
                <h2 className="text-base font-bold tracking-tight">{t.settings}</h2>
              </div>
              <button
                onClick={onClose}
                className="text-slate-400 hover:text-white transition-colors p-1 rounded-lg hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Theme Settings (Optional toggle / visual option) */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
                  {t.theme}
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => setLocalSettings({ ...localSettings, theme: 'dark' })}
                    className={`py-2.5 px-4 rounded-xl border text-sm font-medium transition-all cursor-pointer ${
                      localSettings.theme === 'dark'
                        ? 'bg-slate-800 text-white border-indigo-500 shadow-md shadow-indigo-900/15'
                        : 'bg-slate-900/40 text-slate-400 border-slate-800 hover:text-slate-200'
                    }`}
                  >
                    {t.dark}
                  </button>
                  <button
                    onClick={() => setLocalSettings({ ...localSettings, theme: 'light' })}
                    className={`py-2.5 px-4 rounded-xl border text-sm font-medium transition-all cursor-pointer ${
                      localSettings.theme === 'light'
                        ? 'bg-indigo-50 text-indigo-950 border-indigo-300'
                        : 'bg-slate-900/40 text-slate-400 border-slate-800 hover:text-slate-200'
                    }`}
                  >
                    {t.light}
                  </button>
                </div>
              </div>

              {/* Temperature Control */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
                    {t.tempLabel}
                  </span>
                  <span className="text-xs font-mono bg-slate-800 px-2 py-0.5 rounded text-indigo-400 font-bold">
                    {localSettings.temperature}
                  </span>
                </div>
                <div className="flex items-center gap-4">
                  <Sliders className="w-4 h-4 text-slate-500" />
                  <input
                    type="range"
                    min="0"
                    max="1.5"
                    step="0.1"
                    value={localSettings.temperature}
                    onChange={(e) => setLocalSettings({ ...localSettings, temperature: parseFloat(e.target.value) })}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                  />
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  {isRtl 
                    ? 'القيم الأقل تعطي إجابات دقيقة ومتحفظة، بينما القيم الأعلى تجعل المساعد أكثر إبداعاً وابتكاراً.'
                    : 'Lower values offer stable and precise responses, while higher values generate highly creative and expressive copy.'}
                </p>
              </div>

              {/* System Custom Prompts */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
                  {t.systemPrompt}
                </label>
                <textarea
                  rows={3}
                  value={localSettings.systemInstruction}
                  onChange={(e) => setLocalSettings({ ...localSettings, systemInstruction: e.target.value })}
                  placeholder={t.systemPromptPlaceholder}
                  className="w-full text-sm bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/20 font-sans leading-relaxed resize-none"
                />
              </div>

              {/* Autonomic Memory Checkbox */}
              <div className="flex items-start gap-3 p-4 rounded-xl border border-slate-800 bg-slate-950/30">
                <input
                  type="checkbox"
                  id="memoryEnabled"
                  checked={localSettings.memoryEnabled}
                  onChange={(e) => setLocalSettings({ ...localSettings, memoryEnabled: e.target.checked })}
                  className="mt-1 w-4 h-4 rounded border-slate-800 text-indigo-600 bg-slate-900 focus:ring-indigo-500 cursor-pointer"
                />
                <div className="space-y-1">
                  <label htmlFor="memoryEnabled" className="text-xs font-bold text-slate-200 cursor-pointer select-none">
                    {isRtl ? 'تمكين الذاكرة التلقائية' : 'Enable Autonomic Memory'}
                  </label>
                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    {isRtl
                      ? 'يسمح للمساعد بتحليل واستخلاص تفضيلاتك وحفظها تلقائياً لمراعاتها في جميع جلسات العمل.'
                      : 'Allows the AI model to analyze and extract details about your environment and preferences for personalization.'}
                  </p>
                </div>
              </div>

              {/* Dangerous Area */}
              <div className="pt-4 border-t border-slate-800 space-y-3">
                <span className="text-xs font-bold text-rose-500 uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4" />
                  {isRtl ? 'منطقة الخطر' : 'Danger Zone'}
                </span>
                <button
                  onClick={() => {
                    if (window.confirm(t.clearHistoryConfirm)) {
                      onClearAll();
                      onClose();
                    }
                  }}
                  className="w-full py-2.5 px-4 rounded-xl border border-rose-950 hover:bg-rose-950/30 text-rose-400 hover:text-rose-300 font-medium text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  {t.clearHistory}
                </button>
              </div>
            </div>

            {/* Footer Buttons */}
            <div className="flex items-center justify-between p-5 border-t border-slate-800 bg-slate-950/40">
              <button
                onClick={handleReset}
                className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                {isRtl ? 'إعادة ضبط الافتراضيات' : 'Reset Defaults'}
              </button>
              <div className="flex items-center gap-3">
                <button
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-xs font-medium transition-colors cursor-pointer"
                >
                  {isRtl ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  onClick={handleSave}
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium flex items-center gap-1.5 shadow-md shadow-indigo-900/10 transition-all cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  {t.saveSettings}
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
