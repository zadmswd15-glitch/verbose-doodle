export interface Attachment {
  name: string;
  type: string;
  size: number;
  data: string; // Base64 representation of the file for Gemini analysis
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: number;
  attachments?: Attachment[];
  suggestions?: string[];
  searchSources?: { title: string; url: string; }[];
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  userId: string;
}

export interface UserSettings {
  theme: 'dark' | 'light';
  language: 'ar' | 'en';
  temperature: number;
  systemInstruction: string;
  memoryEnabled: boolean;
  activeProvider?: 'gemini' | 'openai' | 'groq' | 'nanabanana';
  openaiKey?: string;
  groqKey?: string;
  telegramToken?: string;
  geminiKey?: string;
  nanabananaKey?: string;
  selectedChatSpace?: string;
  openaiModel?: string;
  groqModel?: string;
  geminiModel?: string;
}

export interface LearnedKnowledge {
  id: string;
  fact: string;
  category: string;
  createdAt: number;
  autoDetected: boolean;
}

export interface UsageLog {
  id: string;
  action: string;
  timestamp: number;
  details: string;
}
